import { useQueryClient } from '@tanstack/react-query';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useState } from 'react';
import { Alert, Pressable, ScrollView, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { findCachedListItem, useAppointment, useChangeStatus, useDeleteAppointment, useStatuses } from '@/api/hooks';
import { customerName } from '@/components/AppointmentRow';
import { Avatar, Button, Card, Divider, ErrorState, Screen, Sheet, Spinner, StatusPill, Text } from '@/components/ui';
import { errorMessage } from '@/lib/api';
import { useFormat } from '@/lib/format';
import { digitsOnly, openUrl } from '@/lib/hooks';
import { space, useTheme } from '@/lib/theme';
import { formatDayLong, formatDuration } from '@/lib/time';

const PAYMENT_LABEL: Record<string, string> = { paid: 'Paid', not_paid: 'Not paid', pending: 'Pending' };

export default function AppointmentDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const apptId = Number(id);
  const router = useRouter();
  const t = useTheme();
  const fmt = useFormat();
  const qc = useQueryClient();
  const q = useAppointment(apptId);
  const statuses = useStatuses();
  const changeStatus = useChangeStatus();
  const remove = useDeleteAppointment();
  const [statusSheet, setStatusSheet] = useState(false);

  if (q.isPending) return <Screen edges={[]}><Spinner fill /></Screen>;
  if (q.isError) return <Screen edges={[]}><ErrorState message={errorMessage(q.error)} onRetry={() => void q.refetch()} /></Screen>;

  const { info, extras } = q.data;
  const current = info.statusObject ?? statuses.data?.find((s) => s.slug === info.status) ?? { slug: info.status, title: info.status, color: '#8f9ca7' };
  const name = customerName(info.customerFirstName, info.customerLastName);
  const cached = findCachedListItem(qc, apptId);
  const phone = info.customerPhone?.trim();

  const applyStatus = (slug: string) => {
    setStatusSheet(false);
    if (slug === info.status) return;
    changeStatus.mutate({ id: apptId, status: slug }, { onError: (e) => Alert.alert('Couldn’t change status', errorMessage(e)) });
  };

  const confirmDelete = () =>
    Alert.alert('Delete this booking?', 'This can’t be undone. Consider cancelling it instead so you keep the record.', [
      { text: 'Keep it', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () => remove.mutate(apptId, { onSuccess: () => router.back(), onError: (e) => Alert.alert('Couldn’t delete', errorMessage(e)) }),
      },
    ]);

  return (
    <Screen edges={['bottom']}>
      <ScrollView contentContainerStyle={{ padding: space.lg, gap: space.lg }}>
        <View style={{ gap: space.xs }}>
          <Text variant="display" tabular>
            {fmt.time(info.startsAt)}
            <Text variant="title" tone="slate" tabular>
              {` to ${fmt.time(info.endsAt)}`}
            </Text>
          </Text>
          <Text tone="slate">{formatDayLong(fmt.dateKey(info.startsAt))}</Text>
        </View>

        {info.status === 'pending' ? (
          <View style={{ flexDirection: 'row', gap: space.sm }}>
            <Button label="Approve" icon="checkmark" loading={changeStatus.isPending} onPress={() => applyStatus('approved')} style={{ flex: 1 }} />
            <Button label="Reject" variant="secondary" disabled={changeStatus.isPending} onPress={() => applyStatus('rejected')} style={{ flex: 1 }} />
          </View>
        ) : null}

        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Status: ${current.title}. Tap to change`}
          onPress={() => setStatusSheet(true)}
          disabled={changeStatus.isPending}
          style={({ pressed }) => ({ opacity: pressed || changeStatus.isPending ? 0.6 : 1 })}
        >
          <Card style={{ flexDirection: 'row', alignItems: 'center', padding: space.md, gap: space.md }}>
            <StatusPill title={current.title} color={current.color} />
            <Text variant="secondary" tone="slate" style={{ flex: 1 }}>
              Change status
            </Text>
            <Ionicons name="chevron-forward" size={18} color={t.slate} />
          </Card>
        </Pressable>

        <Card onPress={() => router.push(`/customer/${info.customerId}`)} style={{ padding: space.md, gap: space.md }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.md }}>
            <Avatar name={name} uri={info.customerProfileImage} size={48} />
            <View style={{ flex: 1 }}>
              <Text variant="heading" numberOfLines={1}>
                {name}
              </Text>
              <Text variant="secondary" tone="slate" numberOfLines={1}>
                {phone || info.customerEmail || 'No contact details'}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={t.slate} />
          </View>
        </Card>
        {phone ? (
          <View style={{ flexDirection: 'row', gap: space.sm }}>
            <Button label="Call" icon="call-outline" variant="secondary" style={{ flex: 1 }} onPress={() => void openUrl(`tel:${phone}`)} />
            <Button label="WhatsApp" icon="logo-whatsapp" variant="secondary" style={{ flex: 1 }} onPress={() => void openUrl(`https://wa.me/${digitsOnly(phone)}`)} />
          </View>
        ) : null}

        <Card>
          <Row label="Service" value={info.serviceName ?? 'None'} />
          {extras.length > 0 ? (
            <>
              <Divider inset={space.lg} />
              <Row label="Extras" value={extras.map((e) => (e.quantity > 1 ? `${e.name} × ${e.quantity}` : e.name)).join(', ')} />
            </>
          ) : null}
          <Divider inset={space.lg} />
          <Row label="Staff" value={info.staffName ?? 'Unassigned'} />
          {info.locationName ? (
            <>
              <Divider inset={space.lg} />
              <Row label="Location" value={info.locationName} />
            </>
          ) : null}
          <Divider inset={space.lg} />
          <Row label="Duration" value={formatDuration(info.endsAt - info.startsAt)} />
          {info.weight > 1 ? (
            <>
              <Divider inset={space.lg} />
              <Row label="People" value={String(info.weight)} />
            </>
          ) : null}
        </Card>

        {cached ? (
          <Card>
            <Row label="Payment" value={PAYMENT_LABEL[cached.paymentStatus] ?? cached.paymentStatus} />
            <Divider inset={space.lg} />
            <Row label="Paid" value={`${fmt.money(cached.paidAmount)} of ${fmt.money(cached.totalPrice)}`} />
          </Card>
        ) : null}

        {info.note ? (
          <Card style={{ padding: space.lg, gap: space.xs }}>
            <Text variant="secondary" tone="slate">
              Note
            </Text>
            <Text selectable>{info.note}</Text>
          </Card>
        ) : null}

        <View style={{ gap: space.sm, marginTop: space.sm }}>
          <Button label="Reschedule" icon="calendar-outline" onPress={() => router.push(`/appointment/reschedule?id=${apptId}`)} />
          <Button label="Delete booking" variant="danger" loading={remove.isPending} onPress={confirmDelete} />
        </View>
      </ScrollView>

      <Sheet visible={statusSheet} onClose={() => setStatusSheet(false)} title="Change status">
        <ScrollView contentContainerStyle={{ paddingBottom: space.md }}>
          {(statuses.data ?? []).map((s) => (
            <Pressable
              key={s.slug}
              accessibilityRole="button"
              onPress={() => applyStatus(s.slug)}
              style={({ pressed }) => ({ minHeight: 54, paddingHorizontal: space.lg, flexDirection: 'row', alignItems: 'center', gap: space.md, backgroundColor: pressed ? t.primarySoft : 'transparent' })}
            >
              <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: s.color }} />
              <Text style={{ flex: 1 }} weight={s.slug === info.status ? 'semibold' : 'regular'}>
                {s.title}
              </Text>
              {s.slug === info.status ? <Ionicons name="checkmark" size={20} color={t.primary} /> : null}
            </Pressable>
          ))}
        </ScrollView>
      </Sheet>
    </Screen>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <View style={{ flexDirection: 'row', paddingHorizontal: space.lg, paddingVertical: space.md, gap: space.md }}>
      <Text tone="slate" style={{ width: 88 }}>
        {label}
      </Text>
      <Text style={{ flex: 1 }}>{value}</Text>
    </View>
  );
}
