import { useLocalSearchParams, useRouter } from 'expo-router';
import { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';

import { splitSlotId, useAvailableTimes, useCreateAppointment, useOptions, useSaveCustomer, useStatuses } from '@/api/hooks';
import type { SelectOption } from '@/api/types';
import { DateStrip } from '@/components/DateStrip';
import { SelectField } from '@/components/SelectField';
import { TimeGrid } from '@/components/TimeGrid';
import { Button, Chip, Field, Screen, Segmented, Spinner, Text } from '@/components/ui';
import { errorMessage } from '@/lib/api';
import { useFormat } from '@/lib/format';
import { space } from '@/lib/theme';

export default function NewBooking() {
  const params = useLocalSearchParams<{ date?: string; customerId?: string; customerName?: string }>();
  const router = useRouter();
  const fmt = useFormat();
  const create = useCreateAppointment();
  const saveCustomer = useSaveCustomer();
  const statuses = useStatuses();
  const locations = useOptions('locations', '');

  const [mode, setMode] = useState<'existing' | 'new'>('existing');
  const [customer, setCustomer] = useState<SelectOption | null>(params.customerId ? { id: Number(params.customerId), name: params.customerName ?? 'Customer' } : null);
  const [first, setFirst] = useState('');
  const [last, setLast] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [location, setLocation] = useState<SelectOption | null>(null);
  const [service, setService] = useState<SelectOption | null>(null);
  const [staff, setStaff] = useState<SelectOption | null>(null);
  const [date, setDate] = useState(params.date ?? fmt.todayKey());
  const [time, setTime] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  const locs = locations.data ?? [];
  // A Booknetic location id of 0 is rejected server-side (PHP treats 0 as "empty"), so with
  // exactly one location we use it silently; with more than one, the field below is required.
  const effLocation: SelectOption | null = locs.length === 1 ? locs[0] : location;
  const noLocations = locations.isSuccess && locs.length === 0;
  const effStatus = status ?? statuses.data?.find((s) => s.slug === 'approved')?.slug ?? statuses.data?.[0]?.slug ?? 'pending';

  const times = useAvailableTimes({ date, service: service?.id ?? 0, staff: staff?.id ?? 0, location: effLocation?.id ?? 0 });

  const customerOk = mode === 'existing' ? !!customer : first.trim().length > 0;
  const canSave = customerOk && !!service && !!staff && !!time && !!effLocation && !saving;

  const submit = async () => {
    if (!canSave || !service || !staff || !time || !effLocation) return;
    setSaving(true);
    try {
      // Booknetic's appointment API always runs in "backend" mode, which requires an existing
      // customer id — it has no way to create a customer inline. So a new customer is created
      // first, then booked.
      let customerId = customer?.id ?? 0;
      if (mode === 'new') {
        const created = await saveCustomer.mutateAsync({
          firstName: first.trim(),
          lastName: last.trim(),
          phone: phone.trim(),
          email: email.trim(),
          note: '',
          gender: '',
          birthdate: '',
          categoryId: 0,
        });
        customerId = created.customerId;
      }

      const result = await create.mutateAsync({
        location: effLocation.id,
        service: service.id,
        staff: staff.id,
        customerId,
        ...splitSlotId(time),
        status: effStatus,
        note: note.trim(),
      });
      const newId = result.ids?.[0];
      if (newId) router.replace(`/appointment/${newId}`);
      else router.back();
    } catch (e) {
      Alert.alert('Couldn’t create the booking', errorMessage(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Screen edges={['bottom']}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ padding: space.lg, gap: space.xl }} keyboardShouldPersistTaps="handled">
          <View style={{ gap: space.md }}>
            <Text variant="heading">Customer</Text>
            <Segmented
              options={[
                { value: 'existing', label: 'Existing' },
                { value: 'new', label: 'New' },
              ]}
              value={mode}
              onChange={setMode}
            />
            {mode === 'existing' ? (
              <SelectField label="Customer" value={customer} onChange={setCustomer} placeholder="Search customers" useSearch={(s, open) => useOptions('customers', s, undefined, open)} />
            ) : (
              <View style={{ gap: space.md }}>
                <Field label="First name" value={first} onChangeText={setFirst} textContentType="givenName" autoCapitalize="words" />
                <Field label="Last name" value={last} onChangeText={setLast} textContentType="familyName" autoCapitalize="words" />
                <Field label="Phone" value={phone} onChangeText={setPhone} keyboardType="phone-pad" textContentType="telephoneNumber" />
                <Field label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" autoCorrect={false} textContentType="emailAddress" />
              </View>
            )}
          </View>

          <View style={{ gap: space.md }}>
            <Text variant="heading">Service</Text>
            {locations.isPending ? <Spinner /> : null}
            {noLocations ? (
              <Text tone="danger">No active location is set up for this business yet — add one on the web dashboard before booking.</Text>
            ) : locs.length > 1 ? (
              <SelectField
                label="Location"
                value={location}
                onChange={(o) => {
                  setLocation(o);
                  setStaff(null);
                  setTime(null);
                }}
                useSearch={(s, open) => useOptions('locations', s, undefined, open)}
              />
            ) : null}
            <SelectField
              label="Service"
              value={service}
              onChange={(o) => {
                setService(o);
                setStaff(null);
                setTime(null);
              }}
              useSearch={(s, open) => useOptions('services', s, undefined, open)}
            />
            <SelectField
              label="Staff"
              value={staff}
              disabled={!service}
              hint={service ? undefined : 'Choose a service first.'}
              onChange={(o) => {
                setStaff(o);
                setTime(null);
              }}
              useSearch={(s, open) => useOptions('staff', s, { serviceId: service?.id, locationId: effLocation?.id || undefined }, open && !!service)}
            />
          </View>

          <View style={{ gap: space.md }}>
            <Text variant="heading">Day and time</Text>
            <DateStrip
              value={date}
              minKey={fmt.todayKey()}
              onChange={(k) => {
                setDate(k);
                setTime(null);
              }}
            />
            <TimeGrid
              ready={!!service && !!staff}
              slots={times.data}
              loading={times.isPending && times.fetchStatus !== 'idle'}
              error={times.isError ? errorMessage(times.error) : undefined}
              value={time}
              onChange={setTime}
            />
          </View>

          {(statuses.data?.length ?? 0) > 1 ? (
            <View style={{ gap: space.md }}>
              <Text variant="heading">Status</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
                {statuses.data?.map((s) => (
                  <Chip key={s.slug} label={s.title} color={s.color} selected={effStatus === s.slug} onPress={() => setStatus(s.slug)} />
                ))}
              </View>
            </View>
          ) : null}

          <Field label="Note (optional)" value={note} onChangeText={setNote} multiline />
        </ScrollView>
        <View style={{ padding: space.lg }}>
          <Button label="Create booking" disabled={!canSave} loading={saving} onPress={() => void submit()} />
        </View>
      </KeyboardAvoidingView>
    </Screen>
  );
}
