import { useLocalSearchParams, useRouter } from 'expo-router';
import { useState } from 'react';
import { Alert, ScrollView, View } from 'react-native';

import { splitSlotId, useAppointment, useAvailableTimes, useOptions, useReschedule } from '@/api/hooks';
import type { SelectOption } from '@/api/types';
import { DateStrip } from '@/components/DateStrip';
import { SelectField } from '@/components/SelectField';
import { TimeGrid } from '@/components/TimeGrid';
import { Button, ErrorState, Screen, Spinner, Text } from '@/components/ui';
import { errorMessage } from '@/lib/api';
import { useFormat } from '@/lib/format';
import { space } from '@/lib/theme';

export default function Reschedule() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const apptId = Number(id);
  const router = useRouter();
  const fmt = useFormat();
  const q = useAppointment(apptId);
  const save = useReschedule();
  const [date, setDate] = useState<string | null>(null);
  const [staff, setStaff] = useState<SelectOption | null>(null);
  const [time, setTime] = useState<string | null>(null);

  const info = q.data?.info;
  const effDate = date ?? (info ? fmt.dateKey(info.startsAt) : fmt.todayKey());
  const effStaff: SelectOption | null = staff ?? (info ? { id: info.staffId, name: info.staffName ?? 'Staff' } : null);
  const times = useAvailableTimes({
    date: effDate,
    service: info?.serviceId ?? 0,
    staff: effStaff?.id ?? 0,
    location: info?.locationId ?? 0,
    excludeId: info?.id,
  });

  if (q.isPending) return <Screen edges={[]}><Spinner fill /></Screen>;
  if (q.isError || !info) return <Screen edges={[]}><ErrorState message={errorMessage(q.error)} onRetry={() => void q.refetch()} /></Screen>;

  const submit = () => {
    if (!time) return;
    save.mutate(
      { id: apptId, ...splitSlotId(time), staffId: effStaff && effStaff.id !== info.staffId ? effStaff.id : 0 },
      { onSuccess: () => router.back(), onError: (e) => Alert.alert('Couldn’t reschedule', errorMessage(e)) },
    );
  };

  return (
    <Screen edges={['bottom']}>
      <ScrollView contentContainerStyle={{ padding: space.lg, gap: space.xl }} keyboardShouldPersistTaps="handled">
        <Text tone="slate">
          Moving {info.customerFirstName}’s {info.serviceName ?? 'booking'}. Only times when the staff member is free are shown.
        </Text>

        <SelectField
          label="Staff"
          value={effStaff}
          onChange={(o) => {
            setStaff(o);
            setTime(null);
          }}
          useSearch={(s, open) => useOptions('staff', s, { locationId: info.locationId, serviceId: info.serviceId }, open)}
        />

        <View style={{ gap: space.md }}>
          <Text variant="heading">Day</Text>
          <DateStrip
            value={effDate}
            minKey={fmt.todayKey()}
            onChange={(k) => {
              setDate(k);
              setTime(null);
            }}
          />
        </View>

        <View style={{ gap: space.md }}>
          <Text variant="heading">Time</Text>
          <TimeGrid ready={!!effStaff} slots={times.data} loading={times.isPending && times.fetchStatus !== 'idle'} error={times.isError ? errorMessage(times.error) : undefined} value={time} onChange={setTime} />
        </View>
      </ScrollView>
      <View style={{ padding: space.lg }}>
        <Button label="Save new time" disabled={!time} loading={save.isPending} onPress={submit} />
      </View>
    </Screen>
  );
}
