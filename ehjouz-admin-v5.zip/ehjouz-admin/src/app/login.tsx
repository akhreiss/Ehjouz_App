import { Ionicons } from '@expo/vector-icons';
import { useEffect, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, View } from 'react-native';

import { Button, Field, Screen, Text } from '@/components/ui';
import { errorMessage } from '@/lib/api';
import { AuthError, useAuth } from '@/lib/auth';
import { APP_NAME, LOCKED_SITE_URL } from '@/lib/config';
import { loadLastSite } from '@/lib/storage';
import { radius, space, useTheme } from '@/lib/theme';

type Mode = 'password' | 'browser' | 'manual';

export default function Login() {
  const t = useTheme();
  const { signIn, signInWithBrowser, signInWithAppPassword } = useAuth();
  const [mode, setMode] = useState<Mode>('password');
  const [site, setSite] = useState(LOCKED_SITE_URL ?? '');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (LOCKED_SITE_URL) return;
    void loadLastSite().then((s) => s && setSite((prev) => prev || s));
  }, []);

  const run = async (fn: () => Promise<void>) => {
    setBusy(true);
    setError(null);
    try {
      await fn();
    } catch (e) {
      setError(e instanceof AuthError ? e.message : errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  const submit = () => {
    if (mode === 'password') return run(() => signIn(site, username, password));
    if (mode === 'browser') return run(() => signInWithBrowser(site));
    return run(() => signInWithAppPassword(site, username, password));
  };

  return (
    <Screen edges={['top', 'bottom']}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ flexGrow: 1, padding: space.xl, gap: space.xl, justifyContent: 'center' }} keyboardShouldPersistTaps="handled">
          <View style={{ gap: space.md }}>
            <View style={{ width: 56, height: 56, borderRadius: radius.md, backgroundColor: t.primary, alignItems: 'center', justifyContent: 'center' }}>
              <Ionicons name="calendar" size={30} color={t.primaryInk} />
            </View>
            <Text variant="display" weight="bold">
              {APP_NAME}
            </Text>
            <Text tone="slate">Sign in to see today’s bookings and manage your schedule.</Text>
          </View>

          <View style={{ gap: space.lg }}>
            {LOCKED_SITE_URL ? null : (
              <Field
                label="Website address"
                value={site}
                onChangeText={setSite}
                placeholder="booking.example.com"
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="url"
                textContentType="URL"
                editable={!busy}
              />
            )}

            {mode !== 'browser' ? (
              <>
                <Field label="Username" value={username} onChangeText={setUsername} autoCapitalize="none" autoCorrect={false} textContentType="username" editable={!busy} />
                <Field
                  label={mode === 'manual' ? 'App password' : 'Password'}
                  value={password}
                  onChangeText={setPassword}
                  autoCapitalize="none"
                  autoCorrect={false}
                  secureTextEntry
                  textContentType={mode === 'manual' ? 'none' : 'password'}
                  editable={!busy}
                />
                {mode === 'manual' ? (
                  <Text variant="caption" tone="slate">
                    Create one in WordPress under Users, Profile, Application Passwords. It isn’t your login password.
                  </Text>
                ) : null}
              </>
            ) : (
              <Text variant="caption" tone="slate">
                You’ll approve access on your booking site. {APP_NAME} never sees your password.
              </Text>
            )}

            {error ? (
              <View style={{ backgroundColor: t.dangerSoft, borderRadius: radius.md, padding: space.md }}>
                <Text variant="secondary" tone="danger" accessibilityLiveRegion="polite">
                  {error}
                </Text>
              </View>
            ) : null}

            <Button label={mode === 'browser' ? 'Continue in browser' : 'Sign in'} loading={busy} onPress={submit} />

            <View style={{ flexDirection: 'row', justifyContent: 'center', gap: space.lg }}>
              {mode !== 'browser' ? (
                <TextLink
                  label="Sign in via browser instead"
                  onPress={() => {
                    setMode('browser');
                    setError(null);
                  }}
                />
              ) : (
                <TextLink
                  label="Use username and password"
                  onPress={() => {
                    setMode('password');
                    setError(null);
                  }}
                />
              )}
              {mode !== 'manual' ? (
                <TextLink
                  label="Paste an app password"
                  onPress={() => {
                    setMode('manual');
                    setError(null);
                  }}
                />
              ) : null}
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </Screen>
  );
}

function TextLink({ label, onPress }: { label: string; onPress: () => void }) {
  return (
    <Pressable accessibilityRole="button" onPress={onPress} style={{ minHeight: 44, alignItems: 'center', justifyContent: 'center' }}>
      <Text tone="primary" variant="caption" weight="medium">
        {label}
      </Text>
    </Pressable>
  );
}
