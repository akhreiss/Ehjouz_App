import { useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';

import { useCustomer, useSaveCustomer } from '@/api/hooks';
import { Button, ErrorState, Field, Screen, Spinner } from '@/components/ui';
import { errorMessage } from '@/lib/api';
import { space } from '@/lib/theme';

export default function CustomerForm() {
  const { id } = useLocalSearchParams<{ id?: string }>();
  const customerId = id ? Number(id) : undefined;
  const router = useRouter();
  const existing = useCustomer(customerId ?? 0);
  const save = useSaveCustomer(customerId);

  const [first, setFirst] = useState('');
  const [last, setLast] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [note, setNote] = useState('');
  const [filled, setFilled] = useState(false);

  useEffect(() => {
    const c = existing.data;
    if (!c || filled) return;
    setFirst(c.firstName ?? '');
    setLast(c.lastName ?? '');
    setPhone(c.phoneNumber ?? '');
    setEmail(c.email ?? '');
    setNote(c.notes ?? '');
    setFilled(true);
  }, [existing.data, filled]);

  if (customerId && existing.isPending) return <Screen edges={[]}><Spinner fill /></Screen>;
  if (customerId && existing.isError) return <Screen edges={[]}><ErrorState message={errorMessage(existing.error)} onRetry={() => void existing.refetch()} /></Screen>;

  const submit = () => {
    const c = existing.data;
    save.mutate(
      {
        firstName: first.trim(),
        lastName: last.trim(),
        phone: phone.trim(),
        email: email.trim(),
        note: note.trim(),
        // The API replaces the whole record, so carry over fields this form doesn't edit.
        gender: c?.gender ?? '',
        birthdate: c?.birthdate ?? '',
        categoryId: c?.categoryId ?? 0,
      },
      { onSuccess: () => router.back(), onError: (e) => Alert.alert('Couldn’t save', errorMessage(e)) },
    );
  };

  return (
    <Screen edges={['bottom']}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={{ padding: space.lg, gap: space.lg }} keyboardShouldPersistTaps="handled">
          <Field label="First name" value={first} onChangeText={setFirst} autoCapitalize="words" textContentType="givenName" />
          <Field label="Last name" value={last} onChangeText={setLast} autoCapitalize="words" textContentType="familyName" />
          <Field label="Phone" value={phone} onChangeText={setPhone} keyboardType="phone-pad" textContentType="telephoneNumber" />
          <Field label="Email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" autoCorrect={false} textContentType="emailAddress" />
          <Field label="Notes" value={note} onChangeText={setNote} multiline />
        </ScrollView>
        <View style={{ padding: space.lg }}>
          <Button label={customerId ? 'Save changes' : 'Add customer'} disabled={!first.trim()} loading={save.isPending} onPress={submit} />
        </View>
      </KeyboardAvoidingView>
    </Screen>
  );
}
