import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { useMemo } from 'react';
import { ScrollView, View } from 'react-native';

import { useAppointmentList, useCustomer } from '@/api/hooks';
import { AppointmentRow } from '@/components/AppointmentRow';
import { Avatar, Button, Card, Divider, EmptyState, ErrorState, IconButton, Screen, Spinner, Text } from '@/components/ui';
import { errorMessage } from '@/lib/api';
import { useFormat } from '@/lib/format';
import { digitsOnly, openUrl } from '@/lib/hooks';
import { space } from '@/lib/theme';
import { formatDayMedium } from '@/lib/time';

export default function CustomerDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const customerId = Number(id);
  const router = useRouter();
  const fmt = useFormat();
  const q = useCustomer(customerId);
  const bookings = useAppointmentList({ search: '', filter: 'all', customerId });
  const rows = useMemo(() => bookings.data?.pages.flatMap((p) => p.data) ?? [], [bookings.data]);

  if (q.isPending) return <Screen edges={[]}><Spinner fill /></Screen>;
  if (q.isError) return <Screen edges={[]}><ErrorState message={errorMessage(q.error)} onRetry={() => void q.refetch()} /></Screen>;

  const c = q.data;
  const name = [c.firstName, c.lastName].filter(Boolean).join(' ') || 'Customer';
  const phone = c.phoneNumber?.trim();

  return (
    <Screen edges={['bottom']}>
      <Stack.Screen options={{ headerRight: () => <IconButton icon="create-outline" label="Edit customer" onPress={() => router.push(`/customer/form?id=${customerId}`)} /> }} />
      <ScrollView contentContainerStyle={{ padding: space.lg, gap: space.lg }}>
        <View style={{ alignItems: 'center', gap: space.sm }}>
          <Avatar name={name} uri={c.profileImage} size={72} />
          <Text variant="display" style={{ textAlign: 'center' }}>
            {name}
          </Text>
          {c.categoryName ? (
            <Text variant="secondary" tone="slate">
              {c.categoryName}
            </Text>
          ) : null}
        </View>

        <View style={{ flexDirection: 'row', gap: space.sm }}>
          {phone ? <Button label="Call" icon="call-outline" variant="secondary" style={{ flex: 1 }} onPress={() => void openUrl(`tel:${phone}`)} /> : null}
          {phone ? <Button label="WhatsApp" icon="logo-whatsapp" variant="secondary" style={{ flex: 1 }} onPress={() => void openUrl(`https://wa.me/${digitsOnly(phone)}`)} /> : null}
          {c.email ? <Button label="Email" icon="mail-outline" variant="secondary" style={{ flex: 1 }} onPress={() => void openUrl(`mailto:${c.email}`)} /> : null}
        </View>

        <Card>
          <Info label="Phone" value={phone || 'Not set'} />
          <Divider inset={space.lg} />
          <Info label="Email" value={c.email || 'Not set'} />
          {c.gender ? (
            <>
              <Divider inset={space.lg} />
              <Info label="Gender" value={c.gender.charAt(0).toUpperCase() + c.gender.slice(1)} />
            </>
          ) : null}
          {c.birthdate ? (
            <>
              <Divider inset={space.lg} />
              <Info label="Birthday" value={c.birthdate} />
            </>
          ) : null}
          {c.lastAppointmentDate ? (
            <>
              <Divider inset={space.lg} />
              <Info label="Last visit" value={c.lastAppointmentDate} />
            </>
          ) : null}
        </Card>

        {c.notes ? (
          <Card style={{ padding: space.lg, gap: space.xs }}>
            <Text variant="secondary" tone="slate">
              Notes
            </Text>
            <Text selectable>{c.notes}</Text>
          </Card>
        ) : null}

        <Button label="Book an appointment" icon="add" onPress={() => router.push(`/appointment/new?customerId=${customerId}&customerName=${encodeURIComponent(name)}`)} />

        <View style={{ gap: space.md }}>
          <Text variant="title">{bookings.data?.pages[0] ? `Bookings (${bookings.data.pages[0].meta.total})` : 'Bookings'}</Text>
          {bookings.isPending ? (
            <Spinner />
          ) : rows.length === 0 ? (
            <Card>
              <EmptyState title="No bookings yet" />
            </Card>
          ) : (
            <View style={{ gap: space.sm }}>
              {rows.map((r) => (
                <AppointmentRow key={r.id} item={r} showDate={formatDayMedium(fmt.dateKey(r.startsAt))} onPress={() => router.push(`/appointment/${r.id}`)} />
              ))}
              {bookings.hasNextPage ? <Button label="Show more" variant="secondary" loading={bookings.isFetchingNextPage} onPress={() => void bookings.fetchNextPage()} /> : null}
            </View>
          )}
        </View>
      </ScrollView>
    </Screen>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <View style={{ flexDirection: 'row', paddingHorizontal: space.lg, paddingVertical: space.md, gap: space.md }}>
      <Text tone="slate" style={{ width: 88 }}>
        {label}
      </Text>
      <Text style={{ flex: 1 }} selectable>
        {value}
      </Text>
    </View>
  );
}
