import { useRouter } from 'expo-router';
import { FlatList, RefreshControl, View } from 'react-native';

import { useMarkRead, useNotifications } from '@/api/hooks';
import type { AppNotification } from '@/api/types';
import { Button, Card, EmptyState, ErrorState, LargeTitle, Screen, Spinner, Text } from '@/components/ui';
import { errorMessage } from '@/lib/api';
import { space, useTheme } from '@/lib/theme';

/** Notification payloads are free-form JSON; look for a booking id under the keys Booknetic's workflow events use. */
function appointmentIdOf(n: AppNotification): number | null {
  if (!n.action_data) return null;
  try {
    const d: unknown = JSON.parse(n.action_data);
    if (typeof d === 'number') return d;
    if (d && typeof d === 'object') {
      const o = d as Record<string, unknown>;
      const id = Number(o.appointment_id ?? o.appointmentId ?? o.id);
      return id > 0 ? id : null;
    }
  } catch {
    const id = Number(n.action_data);
    if (id > 0) return id;
  }
  return null;
}

export default function Alerts() {
  const router = useRouter();
  const t = useTheme();
  const q = useNotifications();
  const mark = useMarkRead();
  const unread = (q.data ?? []).filter((n) => !n.read_at).length;

  const open = (n: AppNotification) => {
    if (!n.read_at) mark.mutate(n.id);
    const id = appointmentIdOf(n);
    if (id) router.push(`/appointment/${id}`);
  };

  return (
    <Screen>
      <LargeTitle
        title="Alerts"
        subtitle={unread > 0 ? `${unread} unread` : undefined}
        right={unread > 0 ? <Button label="Mark all read" variant="ghost" onPress={() => mark.mutate('all')} style={{ minHeight: 40 }} /> : undefined}
      />
      <FlatList
        contentContainerStyle={{ paddingHorizontal: space.lg, paddingBottom: space.xxl, gap: space.sm }}
        data={q.data ?? []}
        keyExtractor={(n) => String(n.id)}
        refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => void q.refetch()} tintColor={t.primary} />}
        ListEmptyComponent={
          q.isPending ? (
            <Spinner />
          ) : q.isError ? (
            <ErrorState message={errorMessage(q.error)} onRetry={() => void q.refetch()} />
          ) : (
            <EmptyState title="No alerts yet" body="New booking and status alerts will show up here." />
          )
        }
        renderItem={({ item }) => (
          <Card onPress={() => open(item)} style={{ padding: space.md, flexDirection: 'row', gap: space.md, alignItems: 'flex-start' }}>
            <View style={{ width: 10, height: 10, borderRadius: 5, marginTop: 7, backgroundColor: item.read_at ? 'transparent' : t.primary }} />
            <View style={{ flex: 1, gap: 2 }}>
              <Text weight={item.read_at ? 'regular' : 'semibold'}>{item.title}</Text>
              {item.message ? (
                <Text variant="secondary" tone="slate">
                  {item.message}
                </Text>
              ) : null}
              <Text variant="caption" tone="slate">
                {item.created_at}
              </Text>
            </View>
          </Card>
        )}
      />
    </Screen>
  );
}
