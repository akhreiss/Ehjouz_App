import Constants from 'expo-constants';
import * as WebBrowser from 'expo-web-browser';
import { Alert, ScrollView, View } from 'react-native';

import { useMe } from '@/api/hooks';
import { Avatar, Button, Card, Divider, LargeTitle, Screen, Segmented, Text } from '@/components/ui';
import { adminUrl, useAuth } from '@/lib/auth';
import { APP_NAME } from '@/lib/config';
import { usePushStatus, type PushStatus } from '@/lib/push';
import { space, useThemePreference, type ThemePreference } from '@/lib/theme';

const APPEARANCE_OPTIONS: Array<{ value: ThemePreference; label: string }> = [
  { value: 'system', label: 'System' },
  { value: 'light', label: 'Light' },
  { value: 'dark', label: 'Dark' },
];

const PUSH_LABEL: Record<PushStatus, string> = {
  unknown: 'Checking…',
  ready: 'On',
  'no-project-id': 'Off — build has no EAS project ID',
  'not-a-device': 'Off — needs a real phone',
  'permission-denied': 'Off — allow notifications in phone settings',
  'token-failed': 'Off — no push token (Expo Go, or FCM/APNs not set up)',
  'server-missing': 'Off — update the Ehjouz Companion plugin',
  'server-failed': 'Off — server rejected registration',
};

export default function Account() {
  const { session, signOut } = useAuth();
  const me = useMe();
  const { preference, setPreference } = useThemePreference();
  const push = usePushStatus();

  const confirmSignOut = () =>
    Alert.alert('Sign out?', 'You’ll need to sign in again to come back.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign out', style: 'destructive', onPress: () => void signOut() },
    ]);

  return (
    <Screen>
      <LargeTitle title="Account" />
      <ScrollView contentContainerStyle={{ paddingHorizontal: space.lg, paddingBottom: space.xxl, gap: space.xl }}>
        <Card style={{ padding: space.lg, flexDirection: 'row', alignItems: 'center', gap: space.md }}>
          <Avatar name={me.data?.name ?? session?.username ?? '?'} size={52} />
          <View style={{ flex: 1 }}>
            <Text variant="heading" numberOfLines={1}>
              {me.data?.name ?? session?.username}
            </Text>
            <Text variant="secondary" tone="slate">
              Business owner
            </Text>
          </View>
        </Card>

        <Card>
          <Info label="Site" value={session?.siteUrl.replace(/^https?:\/\//, '') ?? ''} />
          <Divider inset={space.lg} />
          <Info label="Signed in as" value={session?.username ?? ''} />
          <Divider inset={space.lg} />
          <Info label="Push" value={PUSH_LABEL[push]} />
          <Divider inset={space.lg} />
          <Info label="Version" value={`${APP_NAME} ${Constants.expoConfig?.version ?? ''}`} />
        </Card>

        <View style={{ gap: space.md }}>
          <Text variant="heading">Appearance</Text>
          <Segmented options={APPEARANCE_OPTIONS} value={preference} onChange={setPreference} />
        </View>

        <View style={{ gap: space.sm }}>
          <Text variant="secondary" tone="slate">
            Services, staff, business hours, payments and other settings are managed on the full dashboard.
          </Text>
          <Button label="Open full dashboard" icon="open-outline" variant="secondary" onPress={() => session && void WebBrowser.openBrowserAsync(adminUrl(session))} />
        </View>

        <Button label="Sign out" variant="danger" onPress={confirmSignOut} />
      </ScrollView>
    </Screen>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <View style={{ flexDirection: 'row', paddingHorizontal: space.lg, paddingVertical: space.md, gap: space.md }}>
      <Text tone="slate" style={{ width: 96 }}>
        {label}
      </Text>
      <Text style={{ flex: 1 }} numberOfLines={1} selectable>
        {value}
      </Text>
    </View>
  );
}
