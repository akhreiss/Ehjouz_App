import { useRouter } from 'expo-router';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Animated, RefreshControl, ScrollView, View } from 'react-native';

import { useAppointment, useDayAppointments, useStats } from '@/api/hooks';
import type { AppointmentListItem } from '@/api/types';
import { ThemeToggle } from '@/components/ThemeToggle';
import { customerName, isInactive, isPending, statusColorOf } from '@/components/AppointmentRow';
import { Avatar, Card, EmptyState, ErrorState, Fab, IconButton, LargeTitle, Screen, Spinner, Text } from '@/components/ui';
import { errorMessage } from '@/lib/api';
import { decodeHtml } from '@/lib/decode';
import { useFormat } from '@/lib/format';
import { digitsOnly, openUrl } from '@/lib/hooks';
import { radius, space, useTheme } from '@/lib/theme';
import { addDays, formatDayLong, formatDuration, nowSec } from '@/lib/time';

function change(pct: number | null | undefined): string | null {
  if (pct === null || pct === undefined || Number.isNaN(pct)) return null;
  const rounded = Math.round(pct);
  return `${rounded > 0 ? '+' : ''}${rounded}%`;
}

export default function Today() {
  const router = useRouter();
  const t = useTheme();
  const fmt = useFormat();
  const today = fmt.todayKey();
  const appts = useDayAppointments(today);
  const stats = useStats('today');
  const [now, setNow] = useState(nowSec());
  const [refreshing, setRefreshing] = useState(false);
  const scrollY = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const id = setInterval(() => setNow(nowSec()), 30_000);
    return () => clearInterval(id);
  }, []);

  const rows = appts.data ?? [];
  const activeRows = useMemo(() => rows.filter((r) => !isInactive(r.status)), [rows]);
  // The "now" marker sits before the first booking that hasn't started yet.
  const nowIndex = useMemo(() => {
    const i = rows.findIndex((r) => r.startsAt > now);
    return i === -1 ? rows.length : i;
  }, [rows, now]);

  // Hours booked today: every booking that still holds the time (pending included, canceled/rejected excluded).
  const bookedSeconds = useMemo(() => activeRows.reduce((sum, r) => sum + (r.endsAt - r.startsAt), 0), [activeRows]);
  // Revenue comes from the dashboard stats; if those can't be read, fall back to the value of today's live bookings.
  const revenue = stats.data
    ? { value: decodeHtml(stats.data.revenue), label: 'Revenue', delta: change(stats.data.revenue_change) }
    : { value: fmt.money(activeRows.reduce((sum, r) => sum + (r.totalPrice || 0), 0)), label: 'Booked value', delta: null };

  // Stats can lag or use another range, so today's own rows count too.
  const pendingCount = Math.max(Number(stats.data?.count_by_status?.pending?.count ?? 0), rows.filter((r) => isPending(r.status)).length);
  const canceledCount = Number(stats.data?.count_by_status?.canceled?.count ?? 0);

  const open = (id: number) => router.push(`/appointment/${id}`);
  const refresh = async () => {
    setRefreshing(true);
    await Promise.all([appts.refetch(), stats.refetch()]);
    setRefreshing(false);
  };

  const stickyOpacity = scrollY.interpolate({ inputRange: [90, 140], outputRange: [0, 1], extrapolate: 'clamp' });

  return (
    <Screen>
      <Animated.View
        pointerEvents="none"
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          zIndex: 10,
          opacity: stickyOpacity,
          backgroundColor: t.bg,
          borderBottomWidth: 1,
          borderColor: t.hairline,
        }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: space.lg, paddingVertical: space.sm, gap: space.sm }}>
          <Text variant="heading" style={{ flex: 1 }}>
            Today
          </Text>
          {stats.data ? (
            <Text variant="secondary" tone="primary" weight="semibold" tabular>
              {decodeHtml(stats.data.revenue)}
            </Text>
          ) : null}
        </View>
      </Animated.View>

      <Animated.ScrollView
        contentContainerStyle={{ paddingBottom: 110 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor={t.primary} />}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
      >
        <LargeTitle title="Today" subtitle={formatDayLong(today)} right={<ThemeToggle />} />

        <View style={{ paddingHorizontal: space.lg, gap: space.xl }}>
          {appts.isPending ? (
            <Spinner />
          ) : appts.isError ? (
            <ErrorState message={errorMessage(appts.error)} onRetry={() => void appts.refetch()} />
          ) : (
            <>
              <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 22, paddingVertical: space.sm }}>
                <SideStat value={formatDuration(bookedSeconds)} label="Hours booked" />
                <SideStat value={revenue.value} label={revenue.label} delta={revenue.delta} />
                <SideStat value={String(activeRows.length)} label="Bookings" />
              </View>

              {stats.data ? (
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: -space.lg }}>
                  <View style={{ flexDirection: 'row', gap: space.sm, paddingHorizontal: space.lg }}>
                    <RailChip value={String(stats.data.customers)} label="new customers" />
                    <RailChip value={String(pendingCount)} label="pending" />
                    <RailChip value={String(canceledCount)} label="canceled" />
                  </View>
                </ScrollView>
              ) : null}

              {pendingCount > 0 ? (
                <Card
                  onPress={() => router.push({ pathname: '/calendar', params: { view: 'list', filter: 'pending' } })}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    padding: space.md,
                    gap: space.sm,
                    backgroundColor: t.primary,
                    borderColor: t.primary,
                    borderRadius: radius.lg,
                  }}
                >
                  <Text style={{ flex: 1 }} tone="onPrimary" weight="semibold">
                    Confirm pending bookings
                  </Text>
                  <View style={{ backgroundColor: 'rgba(255,255,255,0.25)', borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 2 }}>
                    <Text tone="onPrimary" variant="caption" weight="bold">
                      {pendingCount}
                    </Text>
                  </View>
                </Card>
              ) : null}

              <View style={{ gap: space.md }}>
                <Text variant="title">Schedule</Text>
                {rows.length === 0 ? (
                  <Card>
                    <EmptyState title="No bookings today" body="New bookings will show up here as they come in." />
                  </Card>
                ) : (
                  <View>
                    {rows.map((r, i) => (
                      <View key={r.id}>
                        {i === nowIndex ? <NowMarker label={fmt.time(now)} /> : null}
                        <TimelineRow item={r} past={r.endsAt <= now} last={i === rows.length - 1 && nowIndex !== rows.length} onPress={() => open(r.id)} />
                      </View>
                    ))}
                    {nowIndex === rows.length ? <NowMarker label={fmt.time(now)} last /> : null}
                  </View>
                )}
              </View>

              <TomorrowSection dayKey={addDays(today, 1)} onOpen={open} />
            </>
          )}
        </View>
      </Animated.ScrollView>
      <Fab label="New booking" onPress={() => router.push('/appointment/new')} />
    </Screen>
  );
}

function SideStat({ value, label, delta }: { value: string; label: string; delta?: string | null }) {
  return (
    <View style={{ alignItems: 'center', minWidth: 66 }}>
      <Text variant="heading" tabular numberOfLines={1}>
        {value}
      </Text>
      <Text variant="caption" tone="slate">
        {label}
      </Text>
      {delta ? (
        <Text variant="caption" tone="slate">
          {delta}
        </Text>
      ) : null}
    </View>
  );
}

function RailChip({ value, label }: { value: string; label: string }) {
  const t = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 5, paddingHorizontal: 13, paddingVertical: 7, borderRadius: radius.pill, borderWidth: 1, borderColor: t.hairline }}>
      <Text variant="body" weight="bold" tabular>
        {value}
      </Text>
      <Text variant="caption" tone="slate">
        {label}
      </Text>
    </View>
  );
}

const GUTTER = 50;
const RAIL = 20;

function TimelineRow({ item, past, last, onPress }: { item: AppointmentListItem; past: boolean; last: boolean; onPress: () => void }) {
  const t = useTheme();
  const fmt = useFormat();
  const inactive = isInactive(item.status);
  const color = statusColorOf(item);
  const name = customerName(item.customerFirstName, item.customerLastName);
  return (
    <View style={{ flexDirection: 'row', alignItems: 'flex-start', opacity: past || inactive ? 0.55 : 1 }}>
      <View style={{ width: GUTTER, paddingTop: 15 }}>
        <Text variant="caption" weight="semibold" tabular tone="slate">
          {fmt.time(item.startsAt)}
        </Text>
      </View>
      <View style={{ width: RAIL, alignSelf: 'stretch', alignItems: 'center' }}>
        <View style={{ position: 'absolute', top: 0, bottom: last ? undefined : -12, width: 1.5, backgroundColor: t.hairline }} />
      </View>
      <View style={{ flex: 1, flexDirection: 'row', gap: space.sm, marginBottom: space.md, alignItems: 'center' }}>
        <Avatar name={name} uri={item.customerProfileImage} size={38} ringColor={color} />
        <View style={{ flex: 1 }}>
          <Text weight="semibold" numberOfLines={1} style={inactive ? { textDecorationLine: 'line-through' } : null}>
            {name}
          </Text>
          <Text variant="secondary" tone="slate" numberOfLines={1}>
            {item.serviceName ?? 'No service'}
            {item.staffName ? `, ${item.staffName}` : ''}
          </Text>
          <Text variant="caption" style={{ color, fontWeight: '600', marginTop: 1 }}>
            {item.statusObject?.title ?? item.status}
          </Text>
        </View>
      </View>
    </View>
  );
}

function NowMarker({ label, last }: { label: string; last?: boolean }) {
  const t = useTheme();
  return (
    <View accessibilityLabel={`Now, ${label}`} style={{ flexDirection: 'row', alignItems: 'center', height: 26, marginBottom: last ? 0 : space.xs }}>
      <View style={{ width: GUTTER }}>
        <Text variant="caption" tone="primary" weight="bold" tabular>
          {label}
        </Text>
      </View>
      <View style={{ width: RAIL, alignItems: 'center' }}>
        <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: t.primary }} />
      </View>
      <View style={{ flex: 1, height: 1.5, backgroundColor: t.primary }} />
    </View>
  );
}

function TomorrowSection({ dayKey, onOpen }: { dayKey: string; onOpen: (id: number) => void }) {
  const tomorrow = useDayAppointments(dayKey);
  const rows = useMemo(() => (tomorrow.data ?? []).filter((r) => !isInactive(r.status)), [tomorrow.data]);

  // Secondary section — if it fails to load, Today's own schedule above still works fine.
  if (tomorrow.isError) return null;

  return (
    <View style={{ gap: space.md }}>
      <Text variant="title">Tomorrow</Text>
      {tomorrow.isPending ? (
        <Spinner />
      ) : rows.length === 0 ? (
        <Card>
          <EmptyState title="Nothing booked yet" body="Tomorrow is wide open so far." />
        </Card>
      ) : (
        <View style={{ gap: space.sm }}>
          {rows.map((r) => (
            <TomorrowRow key={r.id} item={r} onPress={() => onOpen(r.id)} />
          ))}
        </View>
      )}
    </View>
  );
}

/** Reminder messages need a phone number, which only the appointment-detail endpoint returns — so each row fetches its own detail lazily (cached per id) rather than the list ever carrying it. */
function TomorrowRow({ item, onPress }: { item: AppointmentListItem; onPress: () => void }) {
  const fmt = useFormat();
  const detail = useAppointment(item.id);
  const name = customerName(item.customerFirstName, item.customerLastName);
  const phone = detail.data?.info.customerPhone?.trim();

  const sendReminder = () => {
    if (!phone) return;
    const message =
      `Hi ${item.customerFirstName || 'there'}, just a reminder about your ` +
      `${item.serviceName ?? 'appointment'} tomorrow at ${fmt.time(item.startsAt)}` +
      `${item.staffName ? ` with ${item.staffName}` : ''}. See you then!`;
    void openUrl(`https://wa.me/${digitsOnly(phone)}?text=${encodeURIComponent(message)}`);
  };

  return (
    <Card onPress={onPress} style={{ flexDirection: 'row', alignItems: 'center', padding: space.md, gap: space.md }}>
      <Avatar name={name} uri={item.customerProfileImage} size={38} />
      <View style={{ width: 52 }}>
        <Text variant="secondary" weight="semibold" tabular>
          {fmt.time(item.startsAt)}
        </Text>
      </View>
      <View style={{ flex: 1 }}>
        <Text weight="semibold" numberOfLines={1}>
          {name}
        </Text>
        <Text variant="secondary" tone="slate" numberOfLines={1}>
          {item.serviceName ?? 'No service'}
        </Text>
      </View>
      {phone ? <IconButton icon="logo-whatsapp" label={`Send reminder to ${name}`} onPress={sendReminder} /> : null}
    </Card>
  );
}
