import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useMemo, useState } from 'react';
import { FlatList, RefreshControl, TextInput, View } from 'react-native';

import { useCustomers } from '@/api/hooks';
import type { Customer } from '@/api/types';
import { Avatar, Card, EmptyState, ErrorState, IconButton, LargeTitle, Screen, Spinner, Text } from '@/components/ui';
import { errorMessage } from '@/lib/api';
import { useDebounced } from '@/lib/hooks';
import { fonts, radius, space, useTheme } from '@/lib/theme';

export default function Customers() {
  const router = useRouter();
  const t = useTheme();
  const [search, setSearch] = useState('');
  const q = useCustomers(useDebounced(search.trim()));
  const rows = useMemo(() => q.data?.pages.flatMap((p) => p.data) ?? [], [q.data]);
  const total = q.data?.pages[0]?.meta.total;

  return (
    <Screen>
      <LargeTitle
        title="Customers"
        subtitle={total !== undefined ? `${total} in total` : undefined}
        right={<IconButton icon="person-add-outline" label="Add customer" tone="primary" onPress={() => router.push('/customer/form')} />}
      />
      <View style={{ paddingHorizontal: space.lg, paddingBottom: space.md }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: t.surface, borderRadius: radius.md, borderWidth: 1, borderColor: t.hairline, paddingHorizontal: space.md }}>
          <Ionicons name="search" size={18} color={t.slate} />
          <TextInput
            accessibilityLabel="Search customers"
            placeholder="Search by name, phone or email"
            placeholderTextColor={t.slate}
            value={search}
            onChangeText={setSearch}
            autoCorrect={false}
            returnKeyType="search"
            style={{ flex: 1, minHeight: 46, marginStart: space.sm, fontFamily: fonts.regular, fontSize: 16, color: t.ink }}
          />
        </View>
      </View>
      <FlatList
        contentContainerStyle={{ paddingHorizontal: space.lg, paddingBottom: space.xxl, gap: space.sm }}
        data={rows}
        keyExtractor={(c) => String(c.id)}
        onEndReachedThreshold={0.4}
        onEndReached={() => q.hasNextPage && !q.isFetchingNextPage && void q.fetchNextPage()}
        refreshControl={<RefreshControl refreshing={q.isRefetching && !q.isFetchingNextPage} onRefresh={() => void q.refetch()} tintColor={t.primary} />}
        ListEmptyComponent={
          q.isPending ? (
            <Spinner />
          ) : q.isError ? (
            <ErrorState message={errorMessage(q.error)} onRetry={() => void q.refetch()} />
          ) : (
            <EmptyState title={search ? 'No customers match' : 'No customers yet'} body={search ? 'Try a different search.' : 'Customers appear here after their first booking, or add one now.'} />
          )
        }
        ListFooterComponent={q.isFetchingNextPage ? <Spinner /> : null}
        renderItem={({ item }) => <CustomerRow customer={item} onPress={() => router.push(`/customer/${item.id}`)} />}
      />
    </Screen>
  );
}

function CustomerRow({ customer, onPress }: { customer: Customer; onPress: () => void }) {
  const name = [customer.firstName, customer.lastName].filter(Boolean).join(' ') || 'Customer';
  return (
    <Card onPress={onPress} style={{ flexDirection: 'row', alignItems: 'center', padding: space.md, gap: space.md }}>
      <Avatar name={name} uri={customer.profileImage} />
      <View style={{ flex: 1 }}>
        <Text weight="semibold" numberOfLines={1}>
          {name}
        </Text>
        <Text variant="secondary" tone="slate" numberOfLines={1}>
          {customer.phoneNumber || customer.email || 'No contact details'}
        </Text>
      </View>
    </Card>
  );
}
