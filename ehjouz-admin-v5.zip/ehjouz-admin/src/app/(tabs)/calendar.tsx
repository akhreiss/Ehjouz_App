import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect, useMemo, useState } from 'react';
import { Alert, FlatList, Pressable, RefreshControl, TextInput, View } from 'react-native';

import { useAppointmentList, useBulkChangeStatus, useBulkDeleteAppointments, useRangeAppointments, type ListFilter } from '@/api/hooks';
import type { BulkOperationResult } from '@/api/types';
import { AppointmentRow } from '@/components/AppointmentRow';
import { ThemeToggle } from '@/components/ThemeToggle';
import { Button, Chip, EmptyState, ErrorState, Fab, IconButton, LargeTitle, Screen, Segmented, Spinner, Text } from '@/components/ui';
import { errorMessage } from '@/lib/api';
import { useFormat } from '@/lib/format';
import { useDebounced } from '@/lib/hooks';
import { fonts, radius, space, useTheme } from '@/lib/theme';
import { addDays, dayOfMonth, formatDayLong, formatDayMedium, formatWeekRange, formatWeekdayShort, weekDays } from '@/lib/time';

type Mode = 'week' | 'list';

export default function Calendar() {
  const router = useRouter();
  const fmt = useFormat();
  const { view, filter: filterParam } = useLocalSearchParams<{ view?: string; filter?: string }>();
  const [mode, setMode] = useState<Mode>(view === 'list' ? 'list' : 'week');
  const listFilter: ListFilter = filterParam === 'pending' ? 'pending' : 'upcoming';
  useEffect(() => {
    if (view === 'list') setMode('list');
  }, [view, filterParam]);
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const day = selectedDay ?? fmt.todayKey();

  return (
    <Screen>
      <LargeTitle title="Calendar" right={<ThemeToggle />} />
      <View style={{ paddingHorizontal: space.lg, paddingBottom: space.md }}>
        <Segmented
          options={[
            { value: 'week', label: 'Week' },
            { value: 'list', label: 'All bookings' },
          ]}
          value={mode}
          onChange={setMode}
        />
      </View>
      {mode === 'week' ? <WeekView selectedDay={day} onSelectDay={setSelectedDay} /> : <ListView initialFilter={listFilter} />}
      <Fab label="New booking" onPress={() => router.push(mode === 'week' ? `/appointment/new?date=${day}` : '/appointment/new')} />
    </Screen>
  );
}

function WeekView({ selectedDay, onSelectDay }: { selectedDay: string; onSelectDay: (k: string) => void }) {
  const router = useRouter();
  const t = useTheme();
  const fmt = useFormat();
  const today = fmt.todayKey();
  const days = useMemo(() => weekDays(selectedDay, fmt.weekStartsOn), [selectedDay, fmt.weekStartsOn]);
  const range = useRangeAppointments(days[0], days[6]);
  const [refreshing, setRefreshing] = useState(false);
  const isCurrentWeek = days.includes(today);

  const { marks, forDay } = useMemo(() => {
    const m: Record<string, number> = {};
    const list = [];
    for (const r of range.data ?? []) {
      const k = fmt.dateKey(r.startsAt);
      m[k] = (m[k] ?? 0) + 1;
      if (k === selectedDay) list.push(r);
    }
    return { marks: m, forDay: list };
  }, [range.data, selectedDay, fmt]);

  // Moving a week keeps the same weekday selected, so the list below stays predictable.
  const changeWeek = (n: number) => onSelectDay(addDays(selectedDay, n * 7));

  return (
    <View style={{ flex: 1 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: space.sm }}>
        <IconButton icon="chevron-back" label="Previous week" onPress={() => changeWeek(-1)} />
        <View style={{ alignItems: 'center' }}>
          <Text variant="heading">{formatWeekRange(days)}</Text>
          {!isCurrentWeek ? (
            <Pressable accessibilityRole="button" accessibilityLabel="Jump to this week" hitSlop={8} onPress={() => onSelectDay(today)}>
              <Text variant="caption" tone="primary" weight="semibold">
                Back to today
              </Text>
            </Pressable>
          ) : null}
        </View>
        <IconButton icon="chevron-forward" label="Next week" onPress={() => changeWeek(1)} />
      </View>

      <View style={{ flexDirection: 'row', paddingHorizontal: space.sm, paddingTop: space.xs, paddingBottom: space.xs }}>
        {days.map((k) => {
          const isToday = k === today;
          const isSelected = k === selectedDay;
          const count = marks[k] ?? 0;
          return (
            <Pressable
              key={k}
              accessibilityRole="button"
              accessibilityLabel={`${formatDayLong(k)}${isToday ? ', today' : ''}${count ? `, ${count} bookings` : ''}`}
              accessibilityState={{ selected: isSelected }}
              onPress={() => onSelectDay(k)}
              style={{
                flex: 1,
                height: 68,
                alignItems: 'center',
                justifyContent: 'center',
                borderRadius: radius.md,
                backgroundColor: isSelected ? t.primary : 'transparent',
                borderWidth: isToday && !isSelected ? 1.5 : 0,
                borderColor: t.primary,
              }}
            >
              <Text variant="caption" tone={isSelected ? 'onPrimary' : 'slate'} weight="medium">
                {formatWeekdayShort(k)}
              </Text>
              <Text variant="body" weight={isSelected ? 'bold' : 'medium'} tabular tone={isSelected ? 'onPrimary' : 'ink'}>
                {dayOfMonth(k)}
              </Text>
              <View style={{ flexDirection: 'row', gap: 2.5, marginTop: 3, height: 5 }}>
                {Array.from({ length: Math.min(count, 3) }).map((_, i) => (
                  <View key={i} style={{ width: 5, height: 5, borderRadius: 2.5, backgroundColor: isSelected ? t.primaryInk : t.primary }} />
                ))}
              </View>
            </Pressable>
          );
        })}
      </View>

      <FlatList
        style={{ marginTop: space.sm, borderTopWidth: 1, borderColor: t.hairline }}
        contentContainerStyle={{ paddingHorizontal: space.lg, paddingTop: space.md, paddingBottom: 110, gap: space.sm }}
        data={forDay}
        keyExtractor={(r) => String(r.id)}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            tintColor={t.primary}
            onRefresh={async () => {
              setRefreshing(true);
              await range.refetch();
              setRefreshing(false);
            }}
          />
        }
        ListHeaderComponent={
          <Text variant="secondary" tone="slate" style={{ marginBottom: space.xs }}>
            {formatDayLong(selectedDay)}
            {forDay.length ? `, ${forDay.length} ${forDay.length === 1 ? 'booking' : 'bookings'}` : ''}
          </Text>
        }
        ListEmptyComponent={
          range.isPending ? (
            <Spinner />
          ) : range.isError ? (
            <ErrorState message={errorMessage(range.error)} onRetry={() => void range.refetch()} />
          ) : (
            <EmptyState title="Nothing on this day" body="Tap + to add one." />
          )
        }
        renderItem={({ item }) => <AppointmentRow item={item} onPress={() => router.push(`/appointment/${item.id}`)} />}
      />
    </View>
  );
}

const FILTERS: Array<{ value: ListFilter; label: string }> = [
  { value: 'pending', label: 'Pending' },
  { value: 'upcoming', label: 'Upcoming' },
  { value: 'finished', label: 'Finished' },
  { value: 'all', label: 'All' },
];

/** "5 confirmed" or, when some failed, "3 of 5 confirmed — 2 couldn't be changed". */
function summarize(result: BulkOperationResult, verb: string): string {
  if (result.failed === 0) return `${result.succeeded} ${verb}`;
  return `${result.succeeded} of ${result.processed} ${verb} — ${result.failed} couldn't be changed`;
}

function ListView({ initialFilter }: { initialFilter: ListFilter }) {
  const router = useRouter();
  const t = useTheme();
  const fmt = useFormat();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<ListFilter>(initialFilter);
  // The tab stays mounted, so a new deep link (Today's "Confirm pending bookings") must re-apply its filter.
  useEffect(() => setFilter(initialFilter), [initialFilter]);
  const q = useAppointmentList({ search: useDebounced(search.trim()), filter });
  const rows = useMemo(() => q.data?.pages.flatMap((p) => p.data) ?? [], [q.data]);

  const [selectMode, setSelectMode] = useState(false);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const bulkStatus = useBulkChangeStatus();
  const bulkDelete = useBulkDeleteAppointments();
  const busy = bulkStatus.isPending || bulkDelete.isPending;

  const exitSelect = () => {
    setSelectMode(false);
    setSelected(new Set());
  };
  const toggle = (id: number) =>
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  const runStatus = (status: string, verb: string) => {
    const ids = Array.from(selected);
    bulkStatus.mutate(
      { ids, status },
      {
        onSuccess: (result) => {
          exitSelect();
          Alert.alert('Done', summarize(result, verb));
        },
        onError: (e) => Alert.alert('Couldn’t update these bookings', errorMessage(e)),
      },
    );
  };

  const runDelete = () => {
    const ids = Array.from(selected);
    Alert.alert(`Delete ${ids.length} ${ids.length === 1 ? 'booking' : 'bookings'}?`, 'This can’t be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () =>
          bulkDelete.mutate(ids, {
            onSuccess: (result) => {
              exitSelect();
              Alert.alert('Done', summarize(result, 'deleted'));
            },
            onError: (e) => Alert.alert('Couldn’t delete these bookings', errorMessage(e)),
          }),
      },
    ]);
  };

  return (
    <View style={{ flex: 1 }}>
      <View style={{ paddingHorizontal: space.lg, gap: space.md, paddingBottom: space.md }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: space.sm }}>
          <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: t.surface, borderRadius: radius.md, borderWidth: 1, borderColor: t.hairline, paddingHorizontal: space.md }}>
            <Ionicons name="search" size={18} color={t.slate} />
            <TextInput
              accessibilityLabel="Search bookings"
              placeholder="Search by customer or service"
              placeholderTextColor={t.slate}
              value={search}
              onChangeText={setSearch}
              autoCorrect={false}
              returnKeyType="search"
              style={{ flex: 1, minHeight: 46, marginStart: space.sm, fontFamily: fonts.regular, fontSize: 16, color: t.ink }}
            />
          </View>
          {selectMode ? (
            <Button label="Cancel" variant="ghost" onPress={exitSelect} style={{ minHeight: 46, paddingHorizontal: space.md }} />
          ) : (
            <IconButton icon="checkmark-circle-outline" label="Select bookings" onPress={() => setSelectMode(true)} />
          )}
        </View>
        <View style={{ flexDirection: 'row', gap: space.sm }}>
          {FILTERS.map((f) => (
            <Chip key={f.value} label={f.label} selected={filter === f.value} onPress={() => setFilter(f.value)} />
          ))}
        </View>
      </View>
      <FlatList
        contentContainerStyle={{ paddingHorizontal: space.lg, paddingBottom: selectMode ? 140 : 110, gap: space.sm }}
        data={rows}
        keyExtractor={(r) => String(r.id)}
        onEndReachedThreshold={0.4}
        onEndReached={() => q.hasNextPage && !q.isFetchingNextPage && void q.fetchNextPage()}
        refreshControl={<RefreshControl refreshing={q.isRefetching && !q.isFetchingNextPage} onRefresh={() => void q.refetch()} tintColor={t.primary} />}
        ListEmptyComponent={
          q.isPending ? (
            <Spinner />
          ) : q.isError ? (
            <ErrorState message={errorMessage(q.error)} onRetry={() => void q.refetch()} />
          ) : (
            <EmptyState title="No bookings found" body={search ? 'Try a different search.' : undefined} />
          )
        }
        ListFooterComponent={q.isFetchingNextPage ? <Spinner /> : null}
        renderItem={({ item }) => (
          <AppointmentRow
            item={item}
            showDate={formatDayMedium(fmt.dateKey(item.startsAt))}
            selectable={selectMode}
            selected={selected.has(item.id)}
            onPress={() => (selectMode ? toggle(item.id) : router.push(`/appointment/${item.id}`))}
          />
        )}
      />
      {selectMode && selected.size > 0 ? (
        <View
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: t.surface,
            borderTopWidth: 1,
            borderColor: t.hairline,
            padding: space.md,
            gap: space.sm,
          }}
        >
          <Text variant="secondary" tone="slate">
            {selected.size} selected
          </Text>
          <View style={{ flexDirection: 'row', gap: space.sm }}>
            <Button label="Confirm" variant="secondary" loading={busy} style={{ flex: 1 }} onPress={() => runStatus('approved', 'confirmed')} />
            <Button label="Cancel bookings" variant="secondary" loading={busy} style={{ flex: 1 }} onPress={() => runStatus('canceled', 'canceled')} />
          </View>
          <Button label="Delete" variant="danger" loading={busy} onPress={runDelete} />
        </View>
      ) : null}
    </View>
  );
}
