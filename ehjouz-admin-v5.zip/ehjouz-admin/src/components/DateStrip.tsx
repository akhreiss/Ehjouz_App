import { Ionicons } from '@expo/vector-icons';
import { Pressable, View } from 'react-native';

import { useFormat } from '@/lib/format';
import { radius, space, useTheme } from '@/lib/theme';
import { addDays, dayOfMonth, formatMonth, formatWeekdayShort, startOfWeek } from '@/lib/time';

import { Text } from './ui';

/**
 * One week at a time, with week paging. Replaces a native date picker: booking is
 * mostly "a day this week or next", and it stays in the tenant's calendar, not the phone's.
 */
export function DateStrip({
  value,
  onChange,
  minKey,
  marks,
}: {
  value: string;
  onChange: (key: string) => void;
  minKey?: string;
  /** Number of bookings per day, shown as a small dot. */
  marks?: Record<string, number>;
}) {
  const t = useTheme();
  const fmt = useFormat();
  const today = fmt.todayKey();
  const start = startOfWeek(value, fmt.weekStartsOn);
  const days = Array.from({ length: 7 }, (_, i) => addDays(start, i));

  const shift = (n: number) => {
    const next = addDays(value, n * 7);
    onChange(minKey && next < minKey ? minKey : next);
  };

  return (
    <View style={{ gap: space.sm }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: space.sm }}>
        <Pressable accessibilityRole="button" accessibilityLabel="Previous week" hitSlop={8} onPress={() => shift(-1)} style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name="chevron-back" size={22} color={t.ink} />
        </Pressable>
        <Text variant="heading" style={{ flex: 1, textAlign: 'center' }}>
          {formatMonth(value)}
        </Text>
        <Pressable accessibilityRole="button" accessibilityLabel="Next week" hitSlop={8} onPress={() => shift(1)} style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name="chevron-forward" size={22} color={t.ink} />
        </Pressable>
      </View>
      <View style={{ flexDirection: 'row', paddingHorizontal: space.sm, gap: 4 }}>
        {days.map((k) => {
          const selected = k === value;
          const isToday = k === today;
          const disabled = !!minKey && k < minKey;
          const count = marks?.[k] ?? 0;
          return (
            <Pressable
              key={k}
              accessibilityRole="button"
              accessibilityLabel={`${formatWeekdayShort(k)} ${dayOfMonth(k)}${isToday ? ', today' : ''}`}
              accessibilityState={{ selected, disabled }}
              disabled={disabled}
              onPress={() => onChange(k)}
              style={{
                flex: 1,
                minHeight: 64,
                borderRadius: radius.md,
                alignItems: 'center',
                justifyContent: 'center',
                gap: 2,
                backgroundColor: selected ? t.primary : 'transparent',
                borderWidth: isToday && !selected ? 1 : 0,
                borderColor: t.primary,
                opacity: disabled ? 0.35 : 1,
              }}
            >
              <Text variant="caption" tone={selected ? 'onPrimary' : 'slate'}>
                {formatWeekdayShort(k)}
              </Text>
              <Text variant="heading" tone={selected ? 'onPrimary' : 'ink'} tabular>
                {dayOfMonth(k)}
              </Text>
              <View style={{ height: 5, width: 5, borderRadius: 3, backgroundColor: count > 0 ? (selected ? t.primaryInk : t.primary) : 'transparent' }} />
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}
