import { Ionicons } from '@expo/vector-icons';
import { Alert, View } from 'react-native';

import { useChangeStatus } from '@/api/hooks';
import type { AppointmentListItem } from '@/api/types';
import { errorMessage } from '@/lib/api';
import { useFormat } from '@/lib/format';
import { space, useTheme } from '@/lib/theme';

import { Button, Card, Text } from './ui';

export const INACTIVE_STATUSES = ['canceled', 'cancelled', 'rejected'];

export const isPending = (status: string): boolean => status === 'pending';

export const isInactive = (status: string): boolean => INACTIVE_STATUSES.includes(status);

export const statusColorOf = (item: Pick<AppointmentListItem, 'statusObject'>): string => item.statusObject?.color ?? '#8f9ca7';

export const customerName = (first: string, last?: string | null): string => [first, last].filter(Boolean).join(' ').trim() || 'Customer';

/** Bordered row used in lists: time gutter, status bar, who/what, staff. In select mode, tapping toggles a checkbox instead of navigating. */
export function AppointmentRow({
  item,
  onPress,
  showDate,
  selectable,
  selected,
}: {
  item: AppointmentListItem;
  onPress: () => void;
  showDate?: string;
  selectable?: boolean;
  selected?: boolean;
}) {
  const t = useTheme();
  const fmt = useFormat();
  const inactive = isInactive(item.status);
  const name = customerName(item.customerFirstName, item.customerLastName);
  const changeStatus = useChangeStatus();
  const showApprove = isPending(item.status) && !selectable;
  const approve = () =>
    changeStatus.mutate({ id: item.id, status: 'approved' }, { onError: (e) => Alert.alert('Couldn’t approve', errorMessage(e)) });
  const struck = inactive ? ({ textDecorationLine: 'line-through' } as const) : null;

  return (
    <Card
      onPress={onPress}
      style={{ flexDirection: 'row', alignItems: 'stretch', overflow: 'hidden', opacity: inactive ? 0.7 : 1 }}
    >
      <View style={{ width: 5, backgroundColor: statusColorOf(item) }} />
      {selectable ? (
        <View style={{ width: 44, alignItems: 'center', justifyContent: 'center' }}>
          <View
            style={{
              width: 22,
              height: 22,
              borderRadius: 11,
              borderWidth: selected ? 0 : 1.5,
              borderColor: t.hairline,
              backgroundColor: selected ? t.primary : 'transparent',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {selected ? <Ionicons name="checkmark" size={14} color={t.primaryInk} /> : null}
          </View>
        </View>
      ) : (
        <View style={{ width: 76, paddingVertical: space.md, paddingStart: space.md, justifyContent: 'center' }}>
          <Text variant="heading" tabular>
            {fmt.time(item.startsAt)}
          </Text>
          <Text variant="caption" tone="slate" tabular>
            {fmt.time(item.endsAt)}
          </Text>
        </View>
      )}
      <View style={{ flex: 1, paddingVertical: space.md, paddingEnd: space.md, gap: 2 }}>
        <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 8 }}>
          {selectable ? (
            <Text variant="caption" tone="slate" tabular>
              {fmt.time(item.startsAt)}
            </Text>
          ) : null}
          <Text variant="body" weight="semibold" numberOfLines={1} style={[struck, { flex: 1 }]}>
            {name}
          </Text>
        </View>
        <Text variant="secondary" tone="slate" numberOfLines={1} style={struck}>
          {item.serviceName ?? 'No service'}
        </Text>
        <Text variant="caption" tone="slate" numberOfLines={1}>
          {[showDate, item.staffName ? `with ${item.staffName}` : null].filter(Boolean).join(' · ') || 'No staff assigned'}
        </Text>
        <Text variant="caption" weight="semibold" numberOfLines={1} style={{ color: statusColorOf(item) }}>
          {item.statusObject?.title ?? item.status}
        </Text>
        {showApprove ? (
          <Button label="Approve" icon="checkmark" loading={changeStatus.isPending} onPress={approve} style={{ minHeight: 38, marginTop: space.xs, alignSelf: 'flex-start', paddingHorizontal: space.lg }} />
        ) : null}
      </View>
    </Card>
  );
}
