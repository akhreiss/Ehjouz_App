import { IconButton } from './ui';

import { useThemePreference } from '@/lib/theme';

/** One-tap light/dark switch. Shows the icon of the mode you will switch *to*. */
export function ThemeToggle() {
  const { scheme, toggleScheme } = useThemePreference();
  const toDark = scheme === 'light';
  return <IconButton icon={toDark ? 'moon-outline' : 'sunny-outline'} label={toDark ? 'Switch to dark mode' : 'Switch to light mode'} onPress={toggleScheme} />;
}
