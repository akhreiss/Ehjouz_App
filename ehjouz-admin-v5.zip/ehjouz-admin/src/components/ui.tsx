import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import type { ComponentProps, ReactNode } from 'react';
import {
  ActivityIndicator,
  Modal,
  Pressable,
  Text as RNText,
  TextInput,
  View,
  type StyleProp,
  type TextInputProps,
  type TextProps,
  type TextStyle,
  type ViewStyle,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets, type Edge } from 'react-native-safe-area-context';

import { fonts, radius, space, useTheme } from '@/lib/theme';

/* -------------------------------- Text -------------------------------- */

type Variant = 'display' | 'title' | 'heading' | 'body' | 'secondary' | 'caption';
type Tone = 'ink' | 'slate' | 'primary' | 'danger' | 'onPrimary';
type Weight = keyof typeof fonts;

const VARIANTS: Record<Variant, { size: number; line: number; weight: Weight }> = {
  display: { size: 28, line: 34, weight: 'semibold' },
  title: { size: 20, line: 26, weight: 'semibold' },
  heading: { size: 17, line: 22, weight: 'semibold' },
  body: { size: 16, line: 22, weight: 'regular' },
  secondary: { size: 14, line: 20, weight: 'regular' },
  caption: { size: 12.5, line: 17, weight: 'medium' },
};

export function Text({
  variant = 'body',
  tone = 'ink',
  weight,
  tabular,
  style,
  ...rest
}: TextProps & { variant?: Variant; tone?: Tone; weight?: Weight; tabular?: boolean }) {
  const t = useTheme();
  const v = VARIANTS[variant];
  const color = tone === 'ink' ? t.ink : tone === 'slate' ? t.slate : tone === 'primary' ? t.primary : tone === 'danger' ? t.danger : t.primaryInk;
  return (
    <RNText
      {...rest}
      style={[
        { fontFamily: fonts[weight ?? v.weight], fontSize: v.size, lineHeight: v.line, color },
        tabular ? { fontVariant: ['tabular-nums'] } : null,
        style,
      ]}
    />
  );
}

/* ------------------------------- Layout ------------------------------- */

export function Screen({ children, edges = ['top'], style }: { children: ReactNode; edges?: Edge[]; style?: StyleProp<ViewStyle> }) {
  const t = useTheme();
  return (
    <SafeAreaView edges={edges} style={[{ flex: 1, backgroundColor: t.bg }, style]}>
      {children}
    </SafeAreaView>
  );
}

export function LargeTitle({ title, subtitle, right }: { title: string; subtitle?: string; right?: ReactNode }) {
  return (
    <View style={{ paddingHorizontal: space.lg, paddingTop: space.md, paddingBottom: space.md, flexDirection: 'row', alignItems: 'flex-end', gap: space.md }}>
      <View style={{ flex: 1 }}>
        <Text variant="display" accessibilityRole="header">
          {title}
        </Text>
        {subtitle ? (
          <Text variant="secondary" tone="slate" style={{ marginTop: 2 }}>
            {subtitle}
          </Text>
        ) : null}
      </View>
      {right}
    </View>
  );
}

export function Card({ children, style, onPress }: { children: ReactNode; style?: StyleProp<ViewStyle>; onPress?: () => void }) {
  const t = useTheme();
  const base: ViewStyle = { backgroundColor: t.surface, borderRadius: radius.md, borderWidth: 1, borderColor: t.hairline };
  if (onPress) {
    return (
      <Pressable onPress={onPress} style={({ pressed }) => [base, pressed && { opacity: 0.75 }, style]}>
        {children}
      </Pressable>
    );
  }
  return <View style={[base, style]}>{children}</View>;
}

export function Divider({ inset = 0 }: { inset?: number }) {
  const t = useTheme();
  return <View style={{ height: 1, backgroundColor: t.hairline, marginStart: inset }} />;
}

/* ------------------------------- Controls ------------------------------ */

type IconName = ComponentProps<typeof Ionicons>['name'];

export function Button({
  label,
  onPress,
  variant = 'primary',
  icon,
  loading,
  disabled,
  style,
}: {
  label: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  icon?: IconName;
  loading?: boolean;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
}) {
  const t = useTheme();
  const off = disabled || loading;
  const bg = variant === 'primary' ? t.primary : variant === 'danger' ? t.dangerSoft : variant === 'secondary' ? t.surface : 'transparent';
  const fg = variant === 'primary' ? t.primaryInk : variant === 'danger' ? t.danger : t.primary;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled: !!off, busy: !!loading }}
      disabled={off}
      onPress={onPress}
      style={({ pressed }) => [
        {
          minHeight: 48,
          borderRadius: radius.md,
          paddingHorizontal: space.lg,
          backgroundColor: bg,
          borderWidth: variant === 'secondary' ? 1 : 0,
          borderColor: t.hairline,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          gap: space.sm,
          opacity: off ? 0.5 : pressed ? 0.85 : 1,
        },
        style,
      ]}
    >
      {loading ? <ActivityIndicator color={fg} /> : icon ? <Ionicons name={icon} size={18} color={fg} /> : null}
      <RNText style={{ fontFamily: fonts.semibold, fontSize: 16, color: fg }}>{label}</RNText>
    </Pressable>
  );
}

export function IconButton({ icon, onPress, label, tone = 'ink' }: { icon: IconName; onPress: () => void; label: string; tone?: 'ink' | 'primary' | 'danger' }) {
  const t = useTheme();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      hitSlop={8}
      onPress={onPress}
      style={({ pressed }) => ({ width: 44, height: 44, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.6 : 1 })}
    >
      <Ionicons name={icon} size={24} color={tone === 'primary' ? t.primary : tone === 'danger' ? t.danger : t.ink} />
    </Pressable>
  );
}

export function Chip({ label, selected, onPress, color }: { label: string; selected?: boolean; onPress?: () => void; color?: string }) {
  const t = useTheme();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected: !!selected }}
      onPress={onPress}
      style={({ pressed }) => ({
        minHeight: 40,
        paddingHorizontal: space.lg,
        borderRadius: radius.pill,
        backgroundColor: selected ? t.primary : t.surface,
        borderWidth: 1,
        borderColor: selected ? t.primary : t.hairline,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
        opacity: pressed ? 0.8 : 1,
      })}
    >
      {color ? <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: color }} /> : null}
      <RNText style={{ fontFamily: fonts.medium, fontSize: 14, color: selected ? t.primaryInk : t.ink }}>{label}</RNText>
    </Pressable>
  );
}

export function Segmented<T extends string>({ options, value, onChange }: { options: Array<{ value: T; label: string }>; value: T; onChange: (v: T) => void }) {
  const t = useTheme();
  return (
    <View accessibilityRole="tablist" style={{ flexDirection: 'row', backgroundColor: t.hairline, borderRadius: radius.md, padding: 3 }}>
      {options.map((o) => {
        const on = o.value === value;
        return (
          <Pressable
            key={o.value}
            accessibilityRole="tab"
            accessibilityState={{ selected: on }}
            onPress={() => onChange(o.value)}
            style={{ flex: 1, minHeight: 38, alignItems: 'center', justifyContent: 'center', borderRadius: radius.sm + 1, backgroundColor: on ? t.surface : 'transparent' }}
          >
            <RNText style={{ fontFamily: on ? fonts.semibold : fonts.medium, fontSize: 14, color: on ? t.ink : t.slate }}>{o.label}</RNText>
          </Pressable>
        );
      })}
    </View>
  );
}

export function Field({
  label,
  error,
  style,
  ...rest
}: TextInputProps & { label: string; error?: string; style?: StyleProp<TextStyle> }) {
  const t = useTheme();
  return (
    <View style={{ gap: 6 }}>
      <Text variant="secondary" weight="medium">
        {label}
      </Text>
      <TextInput
        accessibilityLabel={label}
        placeholderTextColor={t.slate}
        {...rest}
        style={[
          {
            minHeight: 48,
            borderRadius: radius.md,
            borderWidth: 1,
            borderColor: error ? t.danger : t.hairline,
            backgroundColor: t.surface,
            paddingHorizontal: space.md,
            paddingVertical: rest.multiline ? space.md : 0,
            fontFamily: fonts.regular,
            fontSize: 16,
            color: t.ink,
            textAlign: 'auto',
          },
          rest.multiline ? { minHeight: 96, textAlignVertical: 'top' } : null,
          style,
        ]}
      />
      {error ? (
        <Text variant="caption" tone="danger">
          {error}
        </Text>
      ) : null}
    </View>
  );
}

/* ------------------------------- Display ------------------------------- */

export function Avatar({ name, uri, size = 44, ringColor }: { name: string; uri?: string | null; size?: number; ringColor?: string }) {
  const t = useTheme();
  const initials =
    name
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((p) => p[0]?.toUpperCase() ?? '')
      .join('') || '?';
  const ring = ringColor ? { borderWidth: 2.5, borderColor: ringColor } : null;
  if (uri && /^https?:\/\//i.test(uri)) {
    return <Image source={{ uri }} style={[{ width: size, height: size, borderRadius: size / 2, backgroundColor: t.primarySoft }, ring]} accessibilityIgnoresInvertColors />;
  }
  return (
    <View style={[{ width: size, height: size, borderRadius: size / 2, backgroundColor: t.primarySoft, alignItems: 'center', justifyContent: 'center' }, ring]}>
      <RNText style={{ fontFamily: fonts.semibold, fontSize: size * 0.36, color: t.primary }}>{initials}</RNText>
    </View>
  );
}

export function StatusPill({ title, color }: { title: string; color: string }) {
  const t = useTheme();
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, minHeight: 26, borderRadius: radius.pill, borderWidth: 1, borderColor: t.hairline, backgroundColor: t.surface }}>
      <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: color }} />
      <Text variant="caption" weight="medium">
        {title}
      </Text>
    </View>
  );
}

export function Spinner({ fill }: { fill?: boolean }) {
  const t = useTheme();
  return (
    <View style={[{ padding: space.xl, alignItems: 'center' }, fill ? { flex: 1, justifyContent: 'center' } : null]}>
      <ActivityIndicator color={t.primary} />
    </View>
  );
}

export function EmptyState({ title, body, action }: { title: string; body?: string; action?: { label: string; onPress: () => void } }) {
  return (
    <View style={{ padding: space.xl, alignItems: 'center', gap: space.sm }}>
      <Text variant="heading" style={{ textAlign: 'center' }}>
        {title}
      </Text>
      {body ? (
        <Text variant="secondary" tone="slate" style={{ textAlign: 'center' }}>
          {body}
        </Text>
      ) : null}
      {action ? <Button label={action.label} onPress={action.onPress} variant="secondary" style={{ marginTop: space.sm }} /> : null}
    </View>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <View style={{ padding: space.xl, alignItems: 'center', gap: space.md }}>
      <Text variant="heading" style={{ textAlign: 'center' }}>
        Couldn’t load this
      </Text>
      <Text variant="secondary" tone="slate" style={{ textAlign: 'center' }}>
        {message}
      </Text>
      {onRetry ? <Button label="Try again" onPress={onRetry} variant="secondary" /> : null}
    </View>
  );
}

/** Round "+" button. `label` is only the accessibility label — the button shows just the plus sign. */
export function Fab({ label, onPress }: { label: string; onPress: () => void }) {
  const t = useTheme();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      style={({ pressed }) => ({
        position: 'absolute',
        end: space.lg,
        bottom: space.lg,
        width: 52,
        height: 52,
        borderRadius: 26,
        backgroundColor: t.primary,
        alignItems: 'center',
        justifyContent: 'center',
        opacity: pressed ? 0.85 : 1,
        shadowColor: '#000',
        shadowOpacity: 0.18,
        shadowRadius: 10,
        shadowOffset: { width: 0, height: 4 },
        elevation: 5,
      })}
    >
      <Ionicons name="add" size={28} color={t.primaryInk} />
    </Pressable>
  );
}

/* --------------------------------- Sheet --------------------------------- */

export function Sheet({ visible, onClose, title, children }: { visible: boolean; onClose: () => void; title: string; children: ReactNode }) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose} statusBarTranslucent>
      <Pressable accessibilityLabel="Close" style={{ flex: 1, backgroundColor: t.overlay }} onPress={onClose} />
      <View
        style={{
          backgroundColor: t.bg,
          borderTopStartRadius: radius.lg,
          borderTopEndRadius: radius.lg,
          maxHeight: '85%',
          paddingBottom: insets.bottom + space.md,
        }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', paddingStart: space.lg, paddingEnd: space.sm, paddingTop: space.sm }}>
          <Text variant="title" style={{ flex: 1 }} accessibilityRole="header">
            {title}
          </Text>
          <IconButton icon="close" onPress={onClose} label="Close" />
        </View>
        {children}
      </View>
    </Modal>
  );
}
