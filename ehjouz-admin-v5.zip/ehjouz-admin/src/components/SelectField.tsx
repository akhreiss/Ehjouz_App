import { Ionicons } from '@expo/vector-icons';
import type { UseQueryResult } from '@tanstack/react-query';
import { useState } from 'react';
import { FlatList, Pressable, TextInput, View } from 'react-native';

import type { SelectOption } from '@/api/types';
import { fonts, radius, space, useTheme } from '@/lib/theme';

import { Divider, EmptyState, Spinner, Sheet, Text } from './ui';

/** Field that opens a searchable bottom sheet. `useSearch` is called with the current search string. */
export function SelectField({
  label,
  value,
  onChange,
  useSearch,
  placeholder = 'Select',
  disabled,
  hint,
}: {
  label: string;
  value: SelectOption | null;
  onChange: (o: SelectOption) => void;
  useSearch: (search: string, open: boolean) => UseQueryResult<SelectOption[]>;
  placeholder?: string;
  disabled?: boolean;
  hint?: string;
}) {
  const t = useTheme();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const q = useSearch(search, open);

  return (
    <View style={{ gap: 6 }}>
      <Text variant="secondary" weight="medium">
        {label}
      </Text>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={`${label}: ${value?.name ?? placeholder}`}
        disabled={disabled}
        onPress={() => setOpen(true)}
        style={({ pressed }) => ({
          minHeight: 48,
          borderRadius: radius.md,
          borderWidth: 1,
          borderColor: t.hairline,
          backgroundColor: t.surface,
          paddingHorizontal: space.md,
          flexDirection: 'row',
          alignItems: 'center',
          opacity: disabled ? 0.5 : pressed ? 0.8 : 1,
        })}
      >
        <Text style={{ flex: 1 }} tone={value ? 'ink' : 'slate'} numberOfLines={1}>
          {value?.name ?? placeholder}
        </Text>
        <Ionicons name="chevron-down" size={18} color={t.slate} />
      </Pressable>
      {hint ? (
        <Text variant="caption" tone="slate">
          {hint}
        </Text>
      ) : null}

      <Sheet visible={open} onClose={() => setOpen(false)} title={label}>
        <View style={{ paddingHorizontal: space.lg, paddingVertical: space.sm }}>
          <TextInput
            accessibilityLabel="Search"
            placeholder="Search"
            placeholderTextColor={t.slate}
            value={search}
            onChangeText={setSearch}
            autoCorrect={false}
            style={{
              minHeight: 44,
              borderRadius: radius.md,
              borderWidth: 1,
              borderColor: t.hairline,
              backgroundColor: t.surface,
              paddingHorizontal: space.md,
              fontFamily: fonts.regular,
              fontSize: 16,
              color: t.ink,
            }}
          />
        </View>
        {q.isPending ? (
          <Spinner />
        ) : (
          <FlatList
            data={q.data ?? []}
            keyExtractor={(o) => String(o.id)}
            keyboardShouldPersistTaps="handled"
            ItemSeparatorComponent={() => <Divider inset={space.lg} />}
            ListEmptyComponent={<EmptyState title="Nothing found" body={search ? 'Try a different search.' : 'There are no options yet.'} />}
            renderItem={({ item }) => (
              <Pressable
                accessibilityRole="button"
                onPress={() => {
                  onChange(item);
                  setOpen(false);
                  setSearch('');
                }}
                style={({ pressed }) => ({ minHeight: 52, paddingHorizontal: space.lg, flexDirection: 'row', alignItems: 'center', backgroundColor: pressed ? t.primarySoft : 'transparent' })}
              >
                <Text style={{ flex: 1 }} weight={item.id === value?.id ? 'semibold' : 'regular'}>
                  {item.name}
                </Text>
                {item.id === value?.id ? <Ionicons name="checkmark" size={20} color={t.primary} /> : null}
              </Pressable>
            )}
          />
        )}
      </Sheet>
    </View>
  );
}
