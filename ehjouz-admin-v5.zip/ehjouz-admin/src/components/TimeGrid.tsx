import { View } from 'react-native';

import type { TimeSlot } from '@/api/types';
import { space } from '@/lib/theme';

import { Chip, Spinner, Text } from './ui';

export function TimeGrid({
  slots,
  loading,
  error,
  ready,
  value,
  onChange,
}: {
  slots: TimeSlot[] | undefined;
  loading: boolean;
  error?: string;
  ready: boolean;
  value: string | null;
  onChange: (time: string) => void;
}) {
  if (!ready) {
    return (
      <Text variant="secondary" tone="slate">
        Choose a service and staff member to see open times.
      </Text>
    );
  }
  if (loading) return <Spinner />;
  if (error) return <Text tone="danger">{error}</Text>;
  if (!slots || slots.length === 0) {
    return (
      <Text variant="secondary" tone="slate">
        No open times on this day. Try another day or staff member.
      </Text>
    );
  }
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: space.sm }}>
      {slots.map((s) => (
        <Chip key={s.id} label={s.text} selected={value === s.id} onPress={() => onChange(s.id)} />
      ))}
    </View>
  );
}
