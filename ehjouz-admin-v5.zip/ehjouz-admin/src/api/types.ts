/** Shapes verified against Booknetic 1.3.5 DTOs (see README). Envelope `{success,message,data}` is unwrapped by lib/api. */

export interface Paged<T> {
  data: T[];
  meta: { total: number; limit: number; skip: number };
}

export interface StatusObject {
  slug: string;
  title: string;
  color: string;
}

export interface AppointmentStatus extends StatusObject {
  icon?: string;
  busy?: boolean;
}

export interface AppointmentListItem {
  id: number;
  startsAt: number;
  endsAt: number;
  status: string;
  statusObject: StatusObject | null;
  paymentStatus: string;
  paidAmount: number;
  totalPrice: number;
  customerFirstName: string;
  customerLastName: string | null;
  customerEmail: string | null;
  customerProfileImage: string | null;
  serviceName: string | null;
  staffId: number | null;
  staffName: string | null;
  staffProfileImage: string | null;
  locationName: string | null;
  createdAt: number;
}

export interface AppointmentInfo {
  id: number;
  startsAt: number;
  endsAt: number;
  status: string;
  statusObject: StatusObject | null;
  note: string | null;
  serviceId: number;
  staffId: number;
  locationId: number;
  customerId: number;
  weight: number;
  serviceName: string | null;
  locationName: string | null;
  customerFirstName: string;
  customerLastName: string | null;
  customerEmail: string | null;
  customerPhone: string | null;
  customerProfileImage: string | null;
  staffName: string | null;
  staffProfileImage: string | null;
}

export interface AppointmentExtra {
  id: number;
  extraId: number;
  name: string;
  duration: number;
  price: number;
  quantity: number;
}

export interface AppointmentDetail {
  info: AppointmentInfo;
  extras: AppointmentExtra[];
  paymentGateways: string[];
}

export interface SelectOption {
  id: number;
  name: string;
}

export interface TimeSlot {
  id: string;
  text: string;
  max_capacity?: number;
  weight?: number;
}

export interface Customer {
  id: number;
  firstName: string;
  lastName: string;
  phoneNumber: string | null;
  email: string | null;
  birthdate: string | null;
  notes: string | null;
  gender: string | null;
  userId: number;
  profileImage: string | null;
  categoryId: number | null;
  categoryName: string | null;
  categoryColor: string | null;
  lastAppointmentDate: string | null;
}

export interface DashboardStats {
  appointments: number;
  revenue: string;
  duration: string;
  count_by_status: Record<string, { count: number | string; status: string }>;
  customers: number;
  appointments_change: number | null;
  customers_change: number | null;
  revenue_change: number | null;
  duration_change: number | null;
}

export type StatsPeriod = 'today' | 'this_week' | 'this_month';

export interface AppNotification {
  id: number;
  user_id: number;
  type: string;
  title: string;
  message: string;
  action_type: string | null;
  action_data: string | null;
  read_at: string | null;
  created_at: string;
}

export interface NotificationsPage {
  notifications: AppNotification[];
  count: number;
}

export interface CreateAppointmentInput {
  location: number;
  service: number;
  staff: number;
  /** Booknetic's REST API always creates appointments in "backend" mode, which requires an existing customer id — see README. */
  customerId: number;
  date: string;
  time: string;
  status: string;
  note: string;
}

export interface SaveCustomerInput {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  note: string;
  gender: string;
  birthdate: string;
  categoryId: number;
}

export interface BulkOperationResult {
  processed: number;
  succeeded: number;
  failed: number;
  succeeded_ids: number[];
  errors: Record<string, string>;
}

