import {
  keepPreviousData,
  useInfiniteQuery,
  useMutation,
  useQuery,
  useQueryClient,
  type QueryClient,
} from '@tanstack/react-query';

import { useApi, type Me } from '@/lib/auth';
import { addDays, DEVICE_ZONE, formatClock, keyOf, offsetSecAt, partsAt, wallToEpoch } from '@/lib/time';
import { useFormat } from '@/lib/format';
import type {
  AppNotification,
  AppointmentDetail,
  AppointmentListItem,
  AppointmentStatus,
  BulkOperationResult,
  CreateAppointmentInput,
  Customer,
  DashboardStats,
  NotificationsPage,
  Paged,
  SaveCustomerInput,
  SelectOption,
  StatsPeriod,
  TimeSlot,
} from './types';

const PAGE = 20;

export function useMe() {
  const api = useApi();
  return useQuery({
    queryKey: ['me'],
    queryFn: () => api.get<Me>('/users/me', { context: 'edit' }, { namespace: 'wp/v2' }),
    staleTime: 10 * 60_000,
  });
}

/* ----------------------------- Appointments ----------------------------- */

/** The server filters days in the tenant's timezone, so fetch a day either side and keep only rows on the phone's calendar day. */
const onPhoneDay = (startKey: string, endKey: string) => (r: Paged<AppointmentListItem>): AppointmentListItem[] =>
  r.data.filter((a) => {
    const k = keyOf(partsAt(a.startsAt, DEVICE_ZONE));
    return k >= startKey && k <= endKey;
  });

export function useDayAppointments(dayKey: string) {
  const api = useApi();
  return useQuery({
    queryKey: ['appointments', 'day', dayKey],
    queryFn: () =>
      api.get<Paged<AppointmentListItem>>('/appointments', {
        startsAt: addDays(dayKey, -1),
        endsAt: `${addDays(dayKey, 1)} 23:59:59`,
        orderByField: 'startsAt',
        orderDirection: 'ASC',
        skip: 0,
        limit: 200,
      }),
    select: onPhoneDay(dayKey, dayKey),
  });
}

export type ListFilter = 'pending' | 'upcoming' | 'finished' | 'all';

export function useAppointmentList(opts: { search: string; filter: ListFilter; customerId?: number }) {
  const api = useApi();
  return useInfiniteQuery({
    queryKey: ['appointments', 'list', opts],
    initialPageParam: 0,
    placeholderData: keepPreviousData,
    queryFn: ({ pageParam }) =>
      api.get<Paged<AppointmentListItem>>('/appointments', {
        skip: pageParam,
        limit: PAGE,
        search: opts.search,
        customerId: opts.customerId ? [opts.customerId] : undefined,
        // Repository semantics: 1 = ended already, 0 = still to come.
        // Pending = every booking still waiting for an answer, whenever it is. Otherwise 1 = ended already, 0 = still to come.
        status: opts.filter === 'pending' ? ['pending'] : undefined,
        isFinished: opts.filter === 'all' || opts.filter === 'pending' ? undefined : opts.filter === 'finished' ? 1 : 0,
        orderByField: 'startsAt',
        orderDirection: opts.filter === 'upcoming' || opts.filter === 'pending' ? 'ASC' : 'DESC',
      }),
    getNextPageParam: (last) => {
      const next = last.meta.skip + last.meta.limit;
      return next < last.meta.total ? next : undefined;
    },
  });
}

export function useAppointment(id: number) {
  const api = useApi();
  return useQuery({
    queryKey: ['appointments', 'detail', id],
    queryFn: () => api.get<AppointmentDetail>(`/appointments/${id}`),
    enabled: id > 0,
  });
}

/** Payment amounts are only on list items; pull them from whichever cached list already has this booking. */
export function findCachedListItem(qc: QueryClient, id: number): AppointmentListItem | undefined {
  for (const [, data] of qc.getQueriesData({ queryKey: ['appointments'] })) {
    const d = data as { data?: AppointmentListItem[]; pages?: Array<{ data: AppointmentListItem[] }> } | AppointmentListItem[] | undefined;
    if (!d || Array.isArray(d)) continue;
    const rows = d.data ?? d.pages?.flatMap((p) => p.data) ?? [];
    const hit = rows.find((r) => r.id === id);
    if (hit) return hit;
  }
  return undefined;
}

export function useStatuses() {
  const api = useApi();
  return useQuery({
    queryKey: ['appointments', 'statuses'],
    queryFn: () => api.get<Record<string, AppointmentStatus> | AppointmentStatus[]>('/appointments/statuses'),
    select: (r): AppointmentStatus[] => Object.values(r),
    staleTime: 60 * 60_000,
  });
}

/** A slot id carries the date and time exactly as the server wants them back: "YYYY-MM-DD HH:MM" in the business's zone. */
export function splitSlotId(id: string): { date: string; time: string } {
  const [date, time] = id.split(' ');
  return { date, time };
}

/**
 * Open times for a day on the PHONE's calendar.
 *
 * The server only works in the business's timezone: it lists slots as plain "HH:MM" for a business-zone date, and
 * reads any booked date + time in that zone too (`client_time_zone` does not change that, and asking for it makes the
 * slot ids and dates disagree). So we ask for the business-zone date(s) that overlap the chosen phone day, convert
 * each slot to phone time, keep those that fall on the chosen day, and hand the original business-zone date/time
 * back when booking (via splitSlotId).
 */
export function useAvailableTimes(p: { date: string; service: number; staff: number; location: number; excludeId?: number }) {
  const api = useApi();
  const fmt = useFormat();
  const ready = !!p.date && p.service > 0 && p.staff > 0;
  const { tenantZone } = fmt;
  const noon = wallToEpoch(p.date, '12:00', DEVICE_ZONE);
  // Hours the business clock is ahead of the phone clock decide which business dates can hold slots of the phone day.
  const diff = offsetSecAt(noon, tenantZone) - offsetSecAt(noon, DEVICE_ZONE);
  const tenantDates = diff > 0 ? [p.date, addDays(p.date, 1)] : diff < 0 ? [addDays(p.date, -1), p.date] : [p.date];
  return useQuery({
    queryKey: ['appointments', 'times', p, tenantDates, tenantZone],
    enabled: ready,
    queryFn: async (): Promise<TimeSlot[]> => {
      const perDate = await Promise.all(
        tenantDates.map(async (date) => ({
          date,
          slots: await api.get<TimeSlot[]>('/appointments/available-times', {
            date,
            service: p.service,
            staff: p.staff,
            location: p.location,
            id: p.excludeId ?? -1,
          }),
        })),
      );
      const out: (TimeSlot & { at: number })[] = [];
      for (const { date, slots } of perDate) {
        for (const slot of slots) {
          if (!/^\d{1,2}:\d{2}$/.test(slot.id)) continue; // e.g. "24:00" is not a bookable start
          const at = wallToEpoch(date, slot.id, tenantZone);
          const phone = partsAt(at, DEVICE_ZONE);
          if (keyOf(phone) !== p.date) continue;
          out.push({ ...slot, id: `${date} ${slot.id}`, text: formatClock(phone, fmt.hour12), at });
        }
      }
      return out.sort((a, b) => a.at - b.at);
    },
  });
}

function useInvalidateBookings() {
  const qc = useQueryClient();
  return () => {
    void qc.invalidateQueries({ queryKey: ['appointments'] });
    void qc.invalidateQueries({ queryKey: ['dashboard'] });
    void qc.invalidateQueries({ queryKey: ['customers'] });
  };
}

export function useChangeStatus() {
  const api = useApi();
  const done = useInvalidateBookings();
  return useMutation({
    mutationFn: (v: { id: number; status: string }) => api.put<void>(`/appointments/${v.id}/change-status`, { status: v.status, run_workflows: 1 }),
    onSuccess: done,
  });
}

export function useReschedule() {
  const api = useApi();
  const done = useInvalidateBookings();
  return useMutation({
    mutationFn: (v: { id: number; date: string; time: string; staffId?: number }) =>
      api.post<{ success: boolean }>(`/appointments/${v.id}/reschedule`, {
        date: v.date,
        time: v.time,
        staffId: v.staffId ?? 0,
        runWorkflows: 1,
      }),
    onSuccess: done,
  });
}

export function useDeleteAppointment() {
  const api = useApi();
  const done = useInvalidateBookings();
  return useMutation({
    mutationFn: (id: number) => api.del<void>(`/appointments/${id}`),
    onSuccess: done,
  });
}

export function useBulkChangeStatus() {
  const api = useApi();
  const done = useInvalidateBookings();
  return useMutation({
    mutationFn: (v: { ids: number[]; status: string }) =>
      api.post<BulkOperationResult>('/appointments/bulk-update', {
        items: v.ids.map((id) => ({ id, status: v.status })),
        runWorkflows: 1,
      }),
    onSuccess: done,
  });
}

export function useBulkDeleteAppointments() {
  const api = useApi();
  const done = useInvalidateBookings();
  return useMutation({
    mutationFn: (ids: number[]) => api.del<BulkOperationResult>('/appointments/bulk', { body: { ids, runWorkflows: 1 } }),
    onSuccess: done,
  });
}

export function useCreateAppointment() {
  const api = useApi();
  const done = useInvalidateBookings();
  return useMutation({
    mutationFn: (v: CreateAppointmentInput) =>
      api.post<{ ids?: number[]; dates?: unknown }>('/appointments', {
        cart: [
          {
            location: v.location,
            service: v.service,
            staff: v.staff,
            customerId: v.customerId,
            date: v.date,
            time: v.time,
            status: v.status,
            note: v.note,
            weight: 1,
            payment_method: 'local',
          },
        ],
        runWorkflows: 1,
      }),
    onSuccess: done,
  });
}

/* ------------------------- Pickers (id + name lists) ------------------------- */

export function useOptions(kind: 'services' | 'staff' | 'customers' | 'locations', search: string, extra?: { locationId?: number; serviceId?: number }, enabled = true) {
  const api = useApi();
  return useQuery({
    queryKey: ['options', kind, search, extra],
    enabled,
    placeholderData: keepPreviousData,
    queryFn: () => api.get<SelectOption[]>(`/appointments/${kind}`, { search, ...extra }),
    staleTime: 60_000,
  });
}

/* -------------------------------- Customers -------------------------------- */

export function useCustomers(search: string) {
  const api = useApi();
  return useInfiniteQuery({
    queryKey: ['customers', 'list', search],
    initialPageParam: 0,
    placeholderData: keepPreviousData,
    queryFn: ({ pageParam }) =>
      api.get<Paged<Customer>>('/customers', { skip: pageParam, limit: PAGE, search, orderByField: '', orderDirection: 'DESC' }),
    getNextPageParam: (last) => {
      const next = last.meta.skip + last.meta.limit;
      return next < last.meta.total ? next : undefined;
    },
  });
}

export function useCustomer(id: number) {
  const api = useApi();
  return useQuery({
    queryKey: ['customers', 'detail', id],
    queryFn: () => api.get<Customer>(`/customers/${id}`),
    enabled: id > 0,
  });
}

export function useSaveCustomer(id?: number) {
  const api = useApi();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (v: SaveCustomerInput) =>
      id ? api.put<{ customerId: number }>(`/customers/${id}`, v) : api.post<{ customerId: number }>('/customers', v),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['customers'] });
      void qc.invalidateQueries({ queryKey: ['options', 'customers'] });
    },
  });
}

/* -------------------------------- Dashboard -------------------------------- */

export function useStats(period: StatsPeriod) {
  const api = useApi();
  return useQuery({
    queryKey: ['dashboard', 'stats', period],
    queryFn: () => api.get<DashboardStats>('/dashboard/stats', { type: period }),
    retry: false, // Staff without the dashboard capability get 403 — the UI just hides the ledger.
  });
}

/** Owner-only capability, same tier as general/payments settings — staff logins can't reach this (not that staff can sign in yet). */

/* ------------------------------- Notifications ------------------------------- */

export function useNotifications() {
  const api = useApi();
  return useQuery({
    queryKey: ['notifications', 'list'],
    queryFn: () => api.get<NotificationsPage>('/mobile-app-notifications', { page: 1, rowsCount: 50 }),
    select: (r): AppNotification[] => r.notifications,
  });
}

export function useUnreadCount() {
  const api = useApi();
  return useQuery({
    queryKey: ['notifications', 'unread'],
    queryFn: () => api.get<{ count: number }>('/mobile-app-notifications/unread-count'),
    select: (r) => Number(r.count) || 0,
    refetchInterval: 60_000,
    retry: false,
  });
}

export function useMarkRead() {
  const api = useApi();
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: number | 'all') => (id === 'all' ? api.post<unknown>('/mobile-app-notifications/mark-all-as-read') : api.post<unknown>('/mobile-app-notifications/mark-as-read', { id })),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ['notifications'] }),
  });
}

export { addDays };

/** All bookings between two calendar days (inclusive) — one query per visible week in Calendar. */
export function useRangeAppointments(startKey: string, endKey: string) {
  const api = useApi();
  return useQuery({
    queryKey: ['appointments', 'range', startKey, endKey],
    placeholderData: keepPreviousData,
    queryFn: () =>
      api.get<Paged<AppointmentListItem>>('/appointments', {
        startsAt: addDays(startKey, -1),
        endsAt: `${addDays(endKey, 1)} 23:59:59`,
        orderByField: 'startsAt',
        orderDirection: 'ASC',
        skip: 0,
        limit: 500,
      }),
    select: onPhoneDay(startKey, endKey),
  });
}
