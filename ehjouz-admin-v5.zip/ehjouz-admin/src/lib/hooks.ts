import { useEffect, useState } from 'react';
import { Alert, Linking } from 'react-native';

export function useDebounced<T>(value: T, ms = 300): T {
  const [v, setV] = useState(value);
  useEffect(() => {
    const id = setTimeout(() => setV(value), ms);
    return () => clearTimeout(id);
  }, [value, ms]);
  return v;
}

export async function openUrl(url: string): Promise<void> {
  try {
    await Linking.openURL(url);
  } catch {
    Alert.alert('Can\u2019t open this', 'No app on this phone can handle it.');
  }
}

export const digitsOnly = (s: string): string => s.replace(/[^\d]/g, '');
