/**
 * Tenant-timezone date helpers.
 *
 * Booknetic stores appointment times as epoch seconds and renders them in the tenant's
 * configured timezone (an IANA name, or an offset like "UTC+3"). We reproduce that here so
 * the phone shows the same wall-clock times as the web panel no matter where the phone is.
 * Calendar dates are handled as "YYYY-MM-DD" keys to avoid device-timezone drift.
 */

export interface Zone {
  tz: string | null;
  offsetMin: number | null;
}

export interface Parts {
  y: number;
  m: number;
  d: number;
  h: number;
  mi: number;
}

export const DEVICE_ZONE: Zone = { tz: null, offsetMin: null };

export function parseZone(raw?: string | null): Zone {
  if (!raw) return DEVICE_ZONE;
  const fixed = raw.trim().match(/^UTC\s*([+-]?\d+(?:\.\d+)?)?$/i);
  if (fixed) return { tz: null, offsetMin: Math.round(parseFloat(fixed[1] ?? '0') * 60) };
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: raw });
    return { tz: raw, offsetMin: null };
  } catch {
    return DEVICE_ZONE;
  }
}

/** Seconds the zone is ahead of UTC at a given instant (DST-aware). */
export function offsetSecAt(epochSec: number, zone: Zone): number {
  const p = partsAt(epochSec, zone);
  return Date.UTC(p.y, p.m - 1, p.d, p.h, p.mi) / 1000 - Math.floor(epochSec / 60) * 60;
}

/** The instant at which a wall clock (YYYY-MM-DD + HH:MM) shows that time in `zone`. */
export function wallToEpoch(dayKey: string, hhmm: string, zone: Zone): number {
  const [h, mi] = hhmm.split(':').map((n) => parseInt(n, 10));
  const asUtc = Date.UTC(parseInt(dayKey.slice(0, 4), 10), parseInt(dayKey.slice(5, 7), 10) - 1, parseInt(dayKey.slice(8, 10), 10), h, mi) / 1000;
  const first = asUtc - offsetSecAt(asUtc, zone);
  return asUtc - offsetSecAt(first, zone); // second pass settles DST boundaries
}

const dtfCache = new Map<string, Intl.DateTimeFormat>();

function dtfFor(tz: string): Intl.DateTimeFormat {
  let f = dtfCache.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat('en-US', {
      timeZone: tz,
      hourCycle: 'h23',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
    dtfCache.set(tz, f);
  }
  return f;
}

export function partsAt(epochSec: number, zone: Zone): Parts {
  const ms = epochSec * 1000;
  if (zone.offsetMin !== null) {
    const dt = new Date(ms + zone.offsetMin * 60_000);
    return { y: dt.getUTCFullYear(), m: dt.getUTCMonth() + 1, d: dt.getUTCDate(), h: dt.getUTCHours(), mi: dt.getUTCMinutes() };
  }
  if (zone.tz) {
    const out: Record<string, number> = {};
    for (const p of dtfFor(zone.tz).formatToParts(ms)) {
      if (p.type !== 'literal') out[p.type] = parseInt(p.value, 10);
    }
    return { y: out.year, m: out.month, d: out.day, h: (out.hour ?? 0) % 24, mi: out.minute ?? 0 };
  }
  const dt = new Date(ms);
  return { y: dt.getFullYear(), m: dt.getMonth() + 1, d: dt.getDate(), h: dt.getHours(), mi: dt.getMinutes() };
}

export const pad = (n: number): string => String(n).padStart(2, '0');

export const keyOf = (p: Parts): string => `${p.y}-${pad(p.m)}-${pad(p.d)}`;

export function keyToDate(key: string): Date {
  const [y, m, d] = key.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d, 12));
}

export function addDays(key: string, n: number): string {
  const dt = keyToDate(key);
  dt.setUTCDate(dt.getUTCDate() + n);
  return `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}-${pad(dt.getUTCDate())}`;
}

export function weekdayOf(key: string): number {
  return keyToDate(key).getUTCDay();
}

export function startOfWeek(key: string, weekStartsOn: number): string {
  const diff = (weekdayOf(key) - weekStartsOn + 7) % 7;
  return addDays(key, -diff);
}

export function daysBetween(a: string, b: string): number {
  return Math.round((keyToDate(b).getTime() - keyToDate(a).getTime()) / 86_400_000);
}

/* -------------------------------- Month grid -------------------------------- */

export const startOfMonth = (monthKey: string): string => `${monthKey}-01`;

export function daysInMonthCount(monthKey: string): number {
  const [y, m] = monthKey.split('-').map(Number);
  return new Date(Date.UTC(y, m, 0)).getUTCDate(); // day 0 of next month = last day of this one
}

export function addMonths(monthKey: string, n: number): string {
  const [y, m] = monthKey.split('-').map(Number);
  const total = y * 12 + (m - 1) + n;
  return `${Math.floor(total / 12)}-${pad((total % 12) + 1)}`;
}

/** All the date keys needed to render a full-week-aligned month grid: leading/trailing days from neighbouring months included, so every row has 7 days. */
export function monthGridDays(monthKey: string, weekStartsOn: number): string[] {
  const first = startOfMonth(monthKey);
  const gridStart = startOfWeek(first, weekStartsOn);
  const last = `${monthKey}-${pad(daysInMonthCount(monthKey))}`;
  const trailing = (weekdayOf(last) - weekStartsOn + 7) % 7;
  const gridEnd = addDays(last, 6 - trailing);

  const days: string[] = [];
  for (let cursor = gridStart; cursor <= gridEnd; cursor = addDays(cursor, 1)) days.push(cursor);
  return days;
}

/** The 7 date keys of the week containing `dayKey`, starting on `weekStartsOn` (0=Sunday). */
export function weekDays(dayKey: string, weekStartsOn: number): string[] {
  const start = startOfWeek(dayKey, weekStartsOn);
  return Array.from({ length: 7 }, (_, i) => addDays(start, i));
}

export const isInMonth = (dayKey: string, monthKey: string): boolean => dayKey.startsWith(monthKey);

const labelFmt = (opts: Intl.DateTimeFormatOptions) => new Intl.DateTimeFormat('en-US', { ...opts, timeZone: 'UTC' });
const fLong = labelFmt({ weekday: 'long', day: 'numeric', month: 'long' });
const fMonth = labelFmt({ month: 'long', year: 'numeric' });
const fWeekdayShort = labelFmt({ weekday: 'short' });
const fMonthShort = labelFmt({ month: 'short' });
const rangeDay = (key: string): string => `${dayOfMonth(key)} ${fMonthShort.format(keyToDate(key))}`;
const fMedium = labelFmt({ weekday: 'short', day: 'numeric', month: 'short' });

/** "21 – 27 Sep 2026", or "28 Sep – 4 Oct 2026" when the week spans months. */
export function formatWeekRange(days: string[]): string {
  const first = days[0];
  const last = days[days.length - 1];
  const year = last.slice(0, 4);
  if (first.slice(0, 7) === last.slice(0, 7)) return `${dayOfMonth(first)} – ${rangeDay(last)} ${year}`;
  return `${rangeDay(first)} – ${rangeDay(last)} ${year}`;
}

export const formatDayLong = (key: string): string => fLong.format(keyToDate(key));
export const formatMonth = (key: string): string => fMonth.format(keyToDate(key));
export const formatWeekdayShort = (key: string): string => fWeekdayShort.format(keyToDate(key));
export const formatDayMedium = (key: string): string => fMedium.format(keyToDate(key));
export const dayOfMonth = (key: string): number => parseInt(key.slice(8, 10), 10);

export function formatClock(p: Pick<Parts, 'h' | 'mi'>, hour12: boolean): string {
  if (!hour12) return `${pad(p.h)}:${pad(p.mi)}`;
  const suffix = p.h >= 12 ? 'PM' : 'AM';
  return `${p.h % 12 === 0 ? 12 : p.h % 12}:${pad(p.mi)} ${suffix}`;
}

export const nowSec = (): number => Math.floor(Date.now() / 1000);

/** "in 23 min", "in 2 h 5 min", "now" — for the next-up card. */
export function untilLabel(startsAt: number, endsAt: number, now = nowSec()): string {
  if (now >= startsAt && now < endsAt) return 'In progress';
  const mins = Math.max(0, Math.round((startsAt - now) / 60));
  if (mins < 1) return 'Starting now';
  if (mins < 60) return `In ${mins} min`;
  const h = Math.floor(mins / 60);
  const r = mins % 60;
  return r === 0 ? `In ${h} h` : `In ${h} h ${r} min`;
}

export function formatDuration(seconds: number): string {
  const mins = Math.round(seconds / 60);
  if (mins < 60) return `${mins} min`;
  const h = Math.floor(mins / 60);
  const r = mins % 60;
  return r === 0 ? `${h} h` : `${h} h ${r} min`;
}
