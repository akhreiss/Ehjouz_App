import Constants from 'expo-constants';
import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';
import { useEffect, useRef, useState } from 'react';
import { Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { useQueryClient } from '@tanstack/react-query';

import { request, type ApiError } from './api';
import { clearPushToken, loadPushToken, savePushToken, type Session } from './storage';

/**
 * Push notifications need a standalone or dev-client build — Expo Go stopped supporting remote
 * push (Android since SDK 53, iOS earlier). Everything here fails soft on Expo Go: permission
 * or token calls just reject and we quietly skip registration, so the rest of the app is
 * unaffected. See README "Push notifications" for the one-time `eas init` this also needs.
 */

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

/** A pending booking's push carries this category, giving it Approve/Reject buttons right on the notification (see the companion plugin's `ehjouz_notify_appointment_mutation`). Both actions foreground the app — the alternative (silent background fulfillment) simply doesn't fire at all once the app has been fully killed, so this is the reliable choice, not just the simple one. */
const PENDING_CATEGORY = 'booking_pending';
const ACTION_APPROVE = 'approve';
const ACTION_REJECT = 'reject';

async function registerCategories(): Promise<void> {
  try {
    await Notifications.setNotificationCategoryAsync(PENDING_CATEGORY, [
      { identifier: ACTION_APPROVE, buttonTitle: 'Approve', options: { opensAppToForeground: true } },
      { identifier: ACTION_REJECT, buttonTitle: 'Reject', options: { isDestructive: true, opensAppToForeground: true } },
    ]);
  } catch {
    // Not supported in this runtime — the notification just falls back to a plain tap.
  }
}

async function ensureAndroidChannel(): Promise<void> {
  if (Platform.OS !== 'android') return;
  await Notifications.setNotificationChannelAsync('default', {
    name: 'Bookings',
    importance: Notifications.AndroidImportance.HIGH,
  });
}

export type PushStatus = 'unknown' | 'ready' | 'no-project-id' | 'not-a-device' | 'permission-denied' | 'token-failed' | 'server-missing' | 'server-failed';

let pushStatus: PushStatus = 'unknown';
const pushListeners = new Set<() => void>();
function setPushStatus(s: PushStatus): void {
  pushStatus = s;
  pushListeners.forEach((l) => l());
}

/** Why this phone is (not) registered for push — shown in Account so a silent skip is visible. */
export function usePushStatus(): PushStatus {
  const [status, set] = useState<PushStatus>(pushStatus);
  useEffect(() => {
    const l = () => set(pushStatus);
    pushListeners.add(l);
    l();
    return () => {
      pushListeners.delete(l);
    };
  }, []);
  return status;
}

function projectId(): string | undefined {
  const extra = Constants.expoConfig?.extra as { eas?: { projectId?: string } } | undefined;
  return extra?.eas?.projectId ?? Constants.easConfig?.projectId;
}

/** Requests permission, gets an Expo push token, and registers it with the Ehjouz Companion plugin. No-op if anything along the way isn't available (Expo Go, simulator, no EAS project, plugin not installed). */
async function registerDeviceToken(session: Session): Promise<void> {
  if (!Device.isDevice) return setPushStatus('not-a-device'); // Simulators/emulators don't have real push tokens.
  const id = projectId();
  if (!id) return setPushStatus('no-project-id'); // App hasn't been linked to an EAS project yet — see README.

  const perms = await Notifications.getPermissionsAsync();
  let granted = perms.granted;
  if (!granted && perms.canAskAgain) {
    granted = (await Notifications.requestPermissionsAsync()).granted;
  }
  if (!granted) return setPushStatus('permission-denied');

  await ensureAndroidChannel();
  await registerCategories();

  let token: string;
  try {
    token = (await Notifications.getExpoPushTokenAsync({ projectId: id })).data;
  } catch {
    return setPushStatus('token-failed'); // Not supported in this runtime (e.g. Expo Go) or missing FCM/APNs credentials — fail soft.
  }

  try {
    await request(session, 'POST', '/devices', {
      namespace: 'ehjouz/v1',
      body: { token, platform: Platform.OS },
    });
    await savePushToken(token);
    setPushStatus('ready');
  } catch (e) {
    // 404 = the companion plugin doesn't have this route yet.
    setPushStatus((e as ApiError)?.status === 404 ? 'server-missing' : 'server-failed');
  }
}

/** Best-effort unregister, called from sign-out while the session is still valid. */
export async function unregisterDeviceToken(session: Session): Promise<void> {
  const token = await loadPushToken();
  if (!token) return;
  try {
    await request(session, 'DELETE', '/devices', { namespace: 'ehjouz/v1', body: { token } });
  } catch {
    // Offline, or already gone — nothing more to do.
  }
  await clearPushToken();
}

/** Registers this device for push once signed in, and routes a notification tap to its booking — or, for a pending booking's Approve/Reject buttons, performs that action directly. */
export function usePushNotifications(session: Session | null): void {
  const router = useRouter();
  const queryClient = useQueryClient();
  const registered = useRef<string | null>(null);
  const sessionRef = useRef<Session | null>(session);
  sessionRef.current = session;

  useEffect(() => {
    if (!session) {
      registered.current = null;
      return;
    }
    if (registered.current === session.username) return; // Already registered this launch.
    registered.current = session.username;
    void registerDeviceToken(session);
  }, [session]);

  useEffect(() => {
    const sub = Notifications.addNotificationResponseReceivedListener((response) => {
      const data = response.notification.request.content.data as { appointmentId?: number } | undefined;
      const appointmentId = data?.appointmentId;
      const action = response.actionIdentifier;
      const activeSession = sessionRef.current;

      if (!appointmentId) return;

      if ((action === ACTION_APPROVE || action === ACTION_REJECT) && activeSession) {
        const status = action === ACTION_APPROVE ? 'approved' : 'rejected';
        request(activeSession, 'PUT', `/appointments/${appointmentId}/change-status`, { body: { status, run_workflows: 1 } })
          .catch(() => {
            // Best effort — opening the booking below still lets the owner act on it manually.
          })
          .finally(() => {
            void queryClient.invalidateQueries({ queryKey: ['appointments'] });
            void queryClient.invalidateQueries({ queryKey: ['dashboard'] });
            void queryClient.invalidateQueries({ queryKey: ['notifications'] });
            router.push(`/appointment/${appointmentId}`);
          });
        return;
      }

      router.push(`/appointment/${appointmentId}`);
    });
    return () => sub.remove();
  }, [router, queryClient]);
}
