import { API_NAMESPACE } from './config';
import type { Session } from './storage';

export class ApiError extends Error {
  status: number;
  fieldErrors?: Record<string, string | string[]>;
  constructor(message: string, status: number, fieldErrors?: Record<string, string | string[]>) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.fieldErrors = fieldErrors;
  }
}

export type QueryValue = string | number | boolean | null | undefined | Array<string | number>;
export type Query = Record<string, QueryValue>;

const TIMEOUT_MS = 20_000;
const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

/** UTF-8 safe base64 (btoa breaks on non-Latin1 usernames, e.g. Arabic). */
export function toBase64(input: string): string {
  const bytes = new TextEncoder().encode(input);
  let out = '';
  for (let i = 0; i < bytes.length; i += 3) {
    const a = bytes[i];
    const b = bytes[i + 1];
    const c = bytes[i + 2];
    out += B64[a >> 2];
    out += B64[((a & 3) << 4) | ((b ?? 0) >> 4)];
    out += b === undefined ? '=' : B64[((b & 15) << 2) | ((c ?? 0) >> 6)];
    out += c === undefined ? '=' : B64[c & 63];
  }
  return out;
}

export function buildQuery(query?: Query): string {
  if (!query) return '';
  const parts: string[] = [];
  for (const [key, value] of Object.entries(query)) {
    if (value === undefined || value === null || value === '') continue;
    if (Array.isArray(value)) {
      for (const v of value) parts.push(`${encodeURIComponent(key)}[]=${encodeURIComponent(String(v))}`);
    } else {
      parts.push(`${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`);
    }
  }
  return parts.join('&');
}

export function restUrl(
  site: Pick<Session, 'siteUrl' | 'restStyle'>,
  namespace: string,
  route: string,
  query?: Query,
): string {
  const qs = buildQuery(query);
  if (site.restStyle === 'plain') {
    return `${site.siteUrl}/?rest_route=/${namespace}${route}${qs ? `&${qs}` : ''}`;
  }
  return `${site.siteUrl}/wp-json/${namespace}${route}${qs ? `?${qs}` : ''}`;
}

/** Turns whatever the user typed into `https://host[/subdir]`. Returns null when it can't be a URL. */
export function normalizeSiteUrl(input: string): string | null {
  let s = input.trim();
  if (!s) return null;
  if (!/^https?:\/\//i.test(s)) s = `https://${s}`;
  const m = s.match(/^(https?:\/\/[^/?#\s]+)([^?#]*)/i);
  if (!m) return null;
  const path = m[2].replace(/\/(wp-admin|wp-login\.php|wp-json)(\/.*)?$/i, '').replace(/\/+$/, '');
  return `${m[1]}${path}`;
}

export interface RequestOptions {
  query?: Query;
  body?: unknown;
  /** REST namespace; defaults to Booknetic. Use `wp/v2` for WordPress core routes. */
  namespace?: string;
  signal?: AbortSignal;
}

export function authHeader(session: Pick<Session, 'username' | 'appPassword'>): string {
  return `Basic ${toBase64(`${session.username}:${session.appPassword}`)}`;
}

interface Envelope {
  success?: boolean;
  message?: string;
  data?: unknown;
}

function isEnvelope(v: unknown): v is Envelope {
  return typeof v === 'object' && v !== null && 'success' in v && 'data' in v;
}

/**
 * Low-level request. Booknetic wraps successful results as `{ success, message, data }`
 * and returns 204 for void endpoints; errors are WP_Error `{ code, message, data: { status, errors } }`.
 */
export async function request<T>(
  session: Session,
  method: 'GET' | 'POST' | 'PUT' | 'DELETE',
  route: string,
  opts: RequestOptions = {},
): Promise<T> {
  const url = restUrl(session, opts.namespace ?? API_NAMESPACE, route, opts.query);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  opts.signal?.addEventListener('abort', () => controller.abort());

  let res: Response;
  try {
    res = await fetch(url, {
      method,
      signal: controller.signal,
      headers: {
        Authorization: authHeader(session),
        Accept: 'application/json',
        ...(opts.body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      },
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    });
  } catch (e) {
    const aborted = e instanceof Error && e.name === 'AbortError';
    throw new ApiError(aborted ? 'The server took too long to respond.' : 'Could not reach the server. Check your connection.', 0);
  } finally {
    clearTimeout(timer);
  }

  if (res.status === 204) return undefined as T;

  const text = await res.text();
  let json: unknown = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    // Non-JSON body (host error page, login redirect...). Handled below.
  }

  if (!res.ok) {
    const err = (json ?? {}) as { message?: string; data?: { errors?: Record<string, string | string[]> } };
    throw new ApiError(err.message || `Request failed (${res.status}).`, res.status, err.data?.errors);
  }
  if (json === null) throw new ApiError('The server returned an unexpected response.', res.status);

  if (isEnvelope(json)) {
    if (json.success === false) throw new ApiError(json.message || 'Request failed.', res.status);
    return json.data as T;
  }
  return json as T;
}

export interface Api {
  session: Session;
  get<T>(route: string, query?: Query, opts?: Omit<RequestOptions, 'query' | 'body'>): Promise<T>;
  post<T>(route: string, body?: unknown, opts?: Omit<RequestOptions, 'body'>): Promise<T>;
  put<T>(route: string, body?: unknown, opts?: Omit<RequestOptions, 'body'>): Promise<T>;
  del<T>(route: string, opts?: RequestOptions): Promise<T>;
}

export function createApi(session: Session, onUnauthorized: () => void): Api {
  const run = async <T,>(method: 'GET' | 'POST' | 'PUT' | 'DELETE', route: string, opts?: RequestOptions) => {
    try {
      return await request<T>(session, method, route, opts);
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) onUnauthorized();
      throw e;
    }
  };
  return {
    session,
    get: (route, query, opts) => run('GET', route, { ...opts, query }),
    post: (route, body, opts) => run('POST', route, { ...opts, body: body ?? {} }),
    put: (route, body, opts) => run('PUT', route, { ...opts, body: body ?? {} }),
    del: (route, opts) => run('DELETE', route, opts),
  };
}

export function errorMessage(e: unknown): string {
  if (e instanceof ApiError) {
    if (e.fieldErrors) {
      const first = Object.values(e.fieldErrors)[0];
      const msg = Array.isArray(first) ? first[0] : first;
      if (msg) return msg;
    }
    if (e.status === 403) return e.message && e.message !== 'Access denied' ? e.message : 'Your account doesn\u2019t have permission to do this.';
    return e.message;
  }
  return e instanceof Error ? e.message : 'Something went wrong.';
}
