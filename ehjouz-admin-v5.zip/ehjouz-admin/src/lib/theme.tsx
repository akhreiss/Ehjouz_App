import * as SecureStore from 'expo-secure-store';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { useColorScheme } from 'react-native';

/**
 * Palette: cool chalk paper / dark charcoal, blue-black ink, one deep marine accent.
 * Appointment status colours come from the server (tenants can customise them), so the
 * chrome stays quiet and lets those carry the meaning.
 */
const light = {
  scheme: 'light' as const,
  bg: '#F3F5F4',
  surface: '#FFFFFF',
  ink: '#13232B',
  slate: '#5E6E76',
  hairline: '#DDE3E2',
  primary: '#0B5C6B',
  primaryInk: '#FFFFFF',
  primarySoft: '#DCEDEF',
  danger: '#C2364A',
  dangerSoft: '#F8E1E4',
  overlay: 'rgba(19,35,43,0.45)',
};

// Mid dark gray, not charcoal-verging-on-black: reads clearly as "dark mode" at a glance,
// without the OLED-crush of near-black.
const dark: Omit<typeof light, 'scheme'> = {
  bg: '#2C3236',
  surface: '#383F43',
  ink: '#F3F6F6',
  slate: '#AEB9BC',
  hairline: '#4C565A',
  primary: '#6FD3E0',
  primaryInk: '#0F2A2F',
  primarySoft: '#3E5459',
  danger: '#F4939C',
  dangerSoft: '#4A3034',
  overlay: 'rgba(0,0,0,0.55)',
};

export type Theme = Omit<typeof light, 'scheme'> & { scheme: 'light' | 'dark' };

export const themes: Record<'light' | 'dark', Theme> = { light, dark: { ...dark, scheme: 'dark' } };

export const fonts = {
  regular: 'IBMPlexSansArabic_400Regular',
  medium: 'IBMPlexSansArabic_500Medium',
  semibold: 'IBMPlexSansArabic_600SemiBold',
  bold: 'IBMPlexSansArabic_700Bold',
} as const;

export const space = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 } as const;
export const radius = { sm: 8, md: 12, lg: 18, pill: 999 } as const;

/* ------------------------------ Preference ------------------------------ */

export type ThemePreference = 'system' | 'light' | 'dark';

const PREF_KEY = 'ehjouz.theme.v1';

interface ThemeContextValue {
  preference: ThemePreference;
  setPreference: (p: ThemePreference) => void;
  toggleScheme: () => void;
  theme: Theme;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const system = useColorScheme();
  const [preference, setPreferenceState] = useState<ThemePreference>('system');

  useEffect(() => {
    let active = true;
    SecureStore.getItemAsync(PREF_KEY)
      .then((v) => {
        if (active && (v === 'light' || v === 'dark' || v === 'system')) setPreferenceState(v);
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, []);

  const setPreference = useCallback((p: ThemePreference) => {
    setPreferenceState(p);
    void SecureStore.setItemAsync(PREF_KEY, p).catch(() => undefined);
  }, []);

  const scheme: 'light' | 'dark' = preference === 'system' ? (system === 'dark' ? 'dark' : 'light') : preference;
  // Quick switch: flips the *effective* scheme and stores it explicitly ("System" stays available in Account).
  const toggleScheme = useCallback(() => setPreference(scheme === 'dark' ? 'light' : 'dark'), [scheme, setPreference]);
  const value = useMemo(() => ({ preference, setPreference, toggleScheme, theme: themes[scheme] }), [preference, setPreference, toggleScheme, scheme]);

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme(): Theme {
  const ctx = useContext(ThemeContext);
  return ctx?.theme ?? themes.light;
}

export function useThemePreference(): { preference: ThemePreference; setPreference: (p: ThemePreference) => void; toggleScheme: () => void; scheme: 'light' | 'dark' } {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useThemePreference must be used inside <ThemeProvider>');
  return { preference: ctx.preference, setPreference: ctx.setPreference, toggleScheme: ctx.toggleScheme, scheme: ctx.theme.scheme };
}
