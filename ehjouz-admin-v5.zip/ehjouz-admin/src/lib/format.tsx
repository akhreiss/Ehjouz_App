import { useQuery } from '@tanstack/react-query';
import { createContext, useContext, useMemo, type ReactNode } from 'react';

import { useAuth } from './auth';
import { DEVICE_ZONE, formatClock, keyOf, nowSec, parseZone, partsAt, type Zone } from './time';

interface GeneralSettings {
  timezone?: string;
  timeFormat?: string;
  weekStartsOn?: string;
}

interface PaymentSettings {
  currency?: string;
  currencySymbol?: string;
  currencyFormat?: number | string;
}

export interface Fmt {
  /** The phone's zone — everything on screen is shown in it. */
  zone: Zone;
  /**
   * The business's zone. The server reads every booked date/time in it, so slots are converted to/from it.
   * Falls back to the phone's zone when the setting isn't readable (staff accounts).
   */
  tenantZone: Zone;
  hour12: boolean;
  /** 0 = Sunday … 6 = Saturday */
  weekStartsOn: number;
  /** Wall-clock time of an epoch, in the phone's timezone. */
  time: (epochSec: number) => string;
  /** Calendar day (YYYY-MM-DD) of an epoch, in the phone's timezone. */
  dateKey: (epochSec: number) => string;
  todayKey: () => string;
  money: (n: number) => string;
}

function weekStart(raw?: string): number {
  const s = (raw ?? '').toLowerCase();
  if (s.startsWith('mon')) return 1;
  if (s.startsWith('sat')) return 6;
  return 0;
}

function build(general?: GeneralSettings, payments?: PaymentSettings): Fmt {
  // Shown in the phone's timezone (the tenant's "show time slots in client time-zone" option).
  const zone = DEVICE_ZONE;
  const tenantZone = parseZone(general?.timezone);
  // PHP time formats: g/h = 12-hour, G/H = 24-hour.
  const hour12 = general?.timeFormat ? /[gh]/.test(general.timeFormat) : false;
  const symbol = payments?.currencySymbol || payments?.currency || '';
  const layout = Number(payments?.currencyFormat) || 1;
  return {
    zone,
    tenantZone,
    hour12,
    weekStartsOn: weekStart(general?.weekStartsOn),
    time: (e) => formatClock(partsAt(e, zone), hour12),
    dateKey: (e) => keyOf(partsAt(e, zone)),
    todayKey: () => keyOf(partsAt(nowSec(), zone)),
    money: (n) => {
      const num = n.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
      if (!symbol) return num;
      switch (layout) {
        case 2:
          return `${symbol} ${num}`;
        case 3:
          return `${num}${symbol}`;
        case 4:
          return `${num} ${symbol}`;
        default:
          return `${symbol}${num}`;
      }
    },
  };
}

const FormatContext = createContext<Fmt>(build());

export function FormatProvider({ children }: { children: ReactNode }) {
  const { api } = useAuth();
  // Both need admin-level capabilities; staff accounts fall back to default week start, 24h clock and plain numbers.
  const general = useQuery({
    queryKey: ['settings', 'general'],
    queryFn: () => api!.get<GeneralSettings>('/settings/general'),
    enabled: !!api,
    retry: false,
    staleTime: 30 * 60_000,
  });
  const payments = useQuery({
    queryKey: ['settings', 'payments'],
    queryFn: () => api!.get<PaymentSettings>('/settings/payments'),
    enabled: !!api,
    retry: false,
    staleTime: 30 * 60_000,
  });
  const fmt = useMemo(() => build(general.data, payments.data), [general.data, payments.data]);
  return <FormatContext.Provider value={fmt}>{children}</FormatContext.Provider>;
}

export function useFormat(): Fmt {
  return useContext(FormatContext);
}
