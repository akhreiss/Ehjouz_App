export const APP_NAME = 'Ehjouz';

/** Stable id so WordPress lists all installs of this app as one entry under "Application Passwords". */
export const APP_ID = '7c1f5f0e-3b8a-4d43-9a3e-6a0d2b6f9c11';

/** When set at build time the app is locked to one server and the login screen hides the site field. */
export const LOCKED_SITE_URL: string | undefined = process.env.EXPO_PUBLIC_LOCKED_SITE_URL || undefined;

export const API_NAMESPACE = 'booknetic/v1';
