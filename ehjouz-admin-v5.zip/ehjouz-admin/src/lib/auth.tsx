import Constants from 'expo-constants';
import { useQueryClient } from '@tanstack/react-query';
import * as Linking from 'expo-linking';
import * as WebBrowser from 'expo-web-browser';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';

import { Api, ApiError, createApi, normalizeSiteUrl, request, restUrl } from './api';
import { API_NAMESPACE, APP_ID, APP_NAME } from './config';
import { clearSession, loadSession, saveSession, type Session } from './storage';
import { unregisterDeviceToken } from './push';

WebBrowser.maybeCompleteAuthSession();

const COMPANION_NAMESPACE = 'ehjouz/v1';

export interface Me {
  id: number;
  name: string;
  slug?: string;
  email?: string;
  roles?: string[];
}

export class AuthError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AuthError';
  }
}

interface SiteInfo {
  restStyle: Session['restStyle'];
  authorizeUrl: string | null;
  hasCompanion: boolean;
}

interface WpIndex {
  namespaces?: string[];
  authentication?: { 'application-passwords'?: { endpoints?: { authorization?: string } } };
}

async function fetchIndex(url: string): Promise<WpIndex | null> {
  try {
    const res = await fetch(url, { headers: { Accept: 'application/json' } });
    if (!res.ok) return null;
    const json = (await res.json()) as WpIndex;
    return Array.isArray(json.namespaces) ? json : null;
  } catch {
    return null;
  }
}

/** Finds the REST root, confirms Booknetic is installed, and notes what else is available (app-password approval page, our companion plugin). */
export async function discoverSite(siteUrl: string): Promise<SiteInfo> {
  let restStyle: Session['restStyle'] = 'pretty';
  let index = await fetchIndex(`${siteUrl}/wp-json/`);
  if (!index) {
    index = await fetchIndex(`${siteUrl}/?rest_route=/`);
    restStyle = 'plain';
  }
  if (!index) {
    throw new AuthError('Couldn\u2019t find a WordPress site at that address. Check the URL and try again.');
  }
  if (!index.namespaces?.includes(API_NAMESPACE)) {
    throw new AuthError('This site doesn\u2019t have Booknetic\u2019s API available. Make sure you entered your Booknetic site address.');
  }
  const authorizeUrl = index.authentication?.['application-passwords']?.endpoints?.authorization ?? null;
  const hasCompanion = !!index.namespaces?.includes(COMPANION_NAMESPACE);
  return { restStyle, authorizeUrl, hasCompanion };
}

const OWNER_ROLES = ['administrator', 'booknetic_saas_tenant'];

/** Admin-level Booknetic roles see everything; anything else (booknetic_staff) is row-scoped server-side. */
export function isOwnerRole(roles: string[] | undefined): boolean {
  return !!roles?.some((r) => OWNER_ROLES.includes(r));
}

/** Confirms the credentials work, and — v1 scope — that this is a tenant-admin account, not staff. */
async function verify(session: Session): Promise<Me> {
  let me: Me;
  try {
    me = await request<Me>(session, 'GET', '/users/me', { namespace: 'wp/v2', query: { context: 'edit' } });
  } catch (e) {
    if (e instanceof ApiError && e.status === 401) {
      throw new AuthError(
        'The site rejected these credentials. If they are correct, the host may be stripping the Authorization header — see the README.',
      );
    }
    throw e;
  }
  if (!isOwnerRole(me.roles)) {
    throw new AuthError('The Ehjouz app currently supports business-owner accounts only. Staff sign-in is coming soon.');
  }
  return me;
}

function param(v: string | string[] | undefined): string {
  return Array.isArray(v) ? (v[0] ?? '') : (v ?? '');
}

function deviceName(): string {
  return Constants.deviceName?.trim() || `${Constants.platform?.ios ? 'iPhone' : 'Android device'}`;
}

interface CompanionLoginResponse {
  username: string;
  password: string;
}

/**
 * Exchanges a real username/password for a scoped WordPress application password, via the
 * Ehjouz Companion plugin (see /wordpress-companion). Returns null — not an error — when that
 * plugin isn't installed, so the caller can fall back to the browser-approval flow.
 */
async function companionLogin(siteUrl: string, restStyle: Session['restStyle'], username: string, password: string): Promise<CompanionLoginResponse | null> {
  const url = restUrl({ siteUrl, restStyle }, COMPANION_NAMESPACE, '/login');
  let res: Response;
  try {
    res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ username, password, device_name: deviceName() }),
    });
  } catch {
    throw new AuthError('Could not reach the server. Check your connection.');
  }
  if (res.status === 404) return null; // Companion plugin not installed on this site.

  const json = (await res.json().catch(() => null)) as { message?: string; username?: string; password?: string } | null;
  if (!res.ok) {
    throw new AuthError(json?.message || 'The username or password is incorrect.');
  }
  if (!json?.username || !json.password) {
    throw new AuthError('The site didn\u2019t return credentials. Please try again.');
  }
  return { username: json.username, password: json.password };
}

interface AuthContextValue {
  status: 'loading' | 'signedOut' | 'signedIn';
  session: Session | null;
  api: Api | null;
  /** Primary flow: site + real username + real password. Falls back to the browser-approval flow automatically if the companion plugin isn't installed. */
  signIn: (siteInput: string, username: string, password: string) => Promise<void>;
  /** Secondary flow: opens the site's own app-password approval page in-browser. */
  signInWithBrowser: (siteInput: string) => Promise<void>;
  /** Manual fallback: paste an already-created application password. */
  signInWithAppPassword: (siteInput: string, username: string, appPassword: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  const [status, setStatus] = useState<AuthContextValue['status']>('loading');
  const [session, setSession] = useState<Session | null>(null);
  const signingOut = useRef(false);

  useEffect(() => {
    let active = true;
    loadSession().then((s) => {
      if (!active) return;
      setSession(s);
      setStatus(s ? 'signedIn' : 'signedOut');
    });
    return () => {
      active = false;
    };
  }, []);

  const endSession = useCallback(async () => {
    if (signingOut.current) return;
    signingOut.current = true;
    await clearSession();
    queryClient.clear();
    setSession(null);
    setStatus('signedOut');
    signingOut.current = false;
  }, [queryClient]);

  const api = useMemo(() => (session ? createApi(session, () => void endSession()) : null), [session, endSession]);

  const commit = useCallback(async (s: Session) => {
    await saveSession(s);
    setSession(s);
    setStatus('signedIn');
  }, []);

  const signInWithBrowser = useCallback(
    async (siteInput: string) => {
      const siteUrl = normalizeSiteUrl(siteInput);
      if (!siteUrl) throw new AuthError('Enter your site address, for example booking.example.com.');
      const info = await discoverSite(siteUrl);
      if (!info.authorizeUrl) {
        throw new AuthError(
          'This site doesn\u2019t offer app passwords. They need HTTPS and can be turned off by security plugins or your host. You can still paste an app password manually.',
        );
      }
      const redirectUrl = Linking.createURL('auth');
      const sep = info.authorizeUrl.includes('?') ? '&' : '?';
      const url =
        `${info.authorizeUrl}${sep}app_name=${encodeURIComponent(APP_NAME)}` +
        `&app_id=${APP_ID}&success_url=${encodeURIComponent(redirectUrl)}&reject_url=${encodeURIComponent(redirectUrl)}`;

      const result = await WebBrowser.openAuthSessionAsync(url, redirectUrl);
      if (result.type !== 'success') throw new AuthError('Sign-in was cancelled.');

      const params = Linking.parse(result.url).queryParams ?? {};
      if (param(params.success) === 'false') throw new AuthError('Access wasn\u2019t approved on the site.');
      const username = param(params.user_login);
      const password = param(params.password).replace(/\s+/g, '');
      if (!username || !password) throw new AuthError('The site didn\u2019t return credentials. Try again or paste an app password manually.');

      const next: Session = { siteUrl, restStyle: info.restStyle, username, appPassword: password };
      await verify(next);
      await commit(next);
    },
    [commit],
  );

  const signInWithAppPassword = useCallback(
    async (siteInput: string, username: string, appPassword: string) => {
      const siteUrl = normalizeSiteUrl(siteInput);
      if (!siteUrl) throw new AuthError('Enter your site address, for example booking.example.com.');
      if (!username.trim() || !appPassword.trim()) throw new AuthError('Enter your username and app password.');
      const info = await discoverSite(siteUrl);
      const next: Session = {
        siteUrl,
        restStyle: info.restStyle,
        username: username.trim(),
        appPassword: appPassword.replace(/\s+/g, ''),
      };
      await verify(next);
      await commit(next);
    },
    [commit],
  );

  const signIn = useCallback(
    async (siteInput: string, username: string, password: string) => {
      const siteUrl = normalizeSiteUrl(siteInput);
      if (!siteUrl) throw new AuthError('Enter your site address, for example booking.example.com.');
      if (!username.trim() || !password.trim()) throw new AuthError('Enter your username and password.');
      const info = await discoverSite(siteUrl);

      if (!info.hasCompanion) {
        throw new AuthError(
          'This site isn\u2019t set up for direct sign-in yet. Use \u201cSign in via browser\u201d below, or ask whoever manages the site to install the Ehjouz Companion plugin.',
        );
      }

      const creds = await companionLogin(siteUrl, info.restStyle, username.trim(), password);
      if (!creds) {
        throw new AuthError('This site isn\u2019t set up for direct sign-in yet. Use \u201cSign in via browser\u201d below instead.');
      }

      const next: Session = { siteUrl, restStyle: info.restStyle, username: creds.username, appPassword: creds.password };
      await verify(next);
      await commit(next);
    },
    [commit],
  );

  const signOut = useCallback(async () => {
    if (session) {
      // Best effort, both non-fatal: forget this device's push token, then revoke its app password.
      await unregisterDeviceToken(session);
      try {
        const current = await request<{ uuid?: string }>(session, 'GET', '/users/me/application-passwords/introspect', { namespace: 'wp/v2' });
        if (current?.uuid) {
          await request(session, 'DELETE', `/users/me/application-passwords/${current.uuid}`, { namespace: 'wp/v2' });
        }
      } catch {
        // Offline or already revoked — nothing to do.
      }
    }
    await endSession();
  }, [session, endSession]);

  const value = useMemo(
    () => ({ status, session, api, signIn, signInWithBrowser, signInWithAppPassword, signOut }),
    [status, session, api, signIn, signInWithBrowser, signInWithAppPassword, signOut],
  );
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}

export function useApi(): Api {
  const { api } = useAuth();
  if (!api) throw new Error('useApi called while signed out');
  return api;
}

export function adminUrl(session: Session): string {
  return `${session.siteUrl}/wp-admin/admin.php?page=booknetic`;
}

export { restUrl };
