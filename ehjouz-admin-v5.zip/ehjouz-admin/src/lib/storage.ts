import * as SecureStore from 'expo-secure-store';

export interface Session {
  /** Origin plus optional sub-directory, no trailing slash, e.g. https://example.com */
  siteUrl: string;
  /** `pretty` = /wp-json/..., `plain` = /?rest_route=/... (sites without pretty permalinks) */
  restStyle: 'pretty' | 'plain';
  username: string;
  appPassword: string;
}

const SESSION_KEY = 'ehjouz.session.v1';
const LAST_SITE_KEY = 'ehjouz.lastsite.v1';
const PUSH_TOKEN_KEY = 'ehjouz.pushtoken.v1';

export async function loadSession(): Promise<Session | null> {
  try {
    const raw = await SecureStore.getItemAsync(SESSION_KEY);
    if (!raw) return null;
    const s = JSON.parse(raw) as Partial<Session>;
    if (!s.siteUrl || !s.username || !s.appPassword) return null;
    return { siteUrl: s.siteUrl, restStyle: s.restStyle === 'plain' ? 'plain' : 'pretty', username: s.username, appPassword: s.appPassword };
  } catch {
    return null;
  }
}

export async function saveSession(session: Session): Promise<void> {
  await SecureStore.setItemAsync(SESSION_KEY, JSON.stringify(session));
  await SecureStore.setItemAsync(LAST_SITE_KEY, session.siteUrl);
}

export async function clearSession(): Promise<void> {
  await SecureStore.deleteItemAsync(SESSION_KEY);
}

export async function loadLastSite(): Promise<string> {
  try {
    return (await SecureStore.getItemAsync(LAST_SITE_KEY)) ?? '';
  } catch {
    return '';
  }
}

/** The Expo push token last registered with the server, so sign-out can unregister the same one. */
export async function loadPushToken(): Promise<string | null> {
  try {
    return await SecureStore.getItemAsync(PUSH_TOKEN_KEY);
  } catch {
    return null;
  }
}

export async function savePushToken(token: string): Promise<void> {
  try {
    await SecureStore.setItemAsync(PUSH_TOKEN_KEY, token);
  } catch {
    // Non-fatal — worst case we just re-register next launch.
  }
}

export async function clearPushToken(): Promise<void> {
  try {
    await SecureStore.deleteItemAsync(PUSH_TOKEN_KEY);
  } catch {
    // Non-fatal.
  }
}
