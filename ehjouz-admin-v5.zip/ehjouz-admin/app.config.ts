import type { ExpoConfig } from 'expo/config';

/**
 * Ehjouz Admin — tenant-admin mobile app for Booknetic (SaaS).
 *
 * Build-time options (set as EXPO_PUBLIC_* env vars, they are inlined into the JS bundle):
 *   EXPO_PUBLIC_LOCKED_SITE_URL   Lock the app to one server (hides the site field on login).
 *                                 Leave unset while developing so you can point at any site.
 *
 * Push notifications need this app linked to an EAS project (one-time `eas init`, or set
 * `extra.eas.projectId` below by hand) plus a dev-client or standalone build — see README.
 */
const config: ExpoConfig = {
  name: 'Ehjouz',
  slug: 'ehjouz-admin',
  scheme: 'ehjouz',
  version: '0.1.0',
  orientation: 'portrait',
  icon: './assets/icon.png',
  userInterfaceStyle: 'automatic',
  ios: {
    supportsTablet: false,
    bundleIdentifier: 'com.ehjouz.admin',
  },
  android: {
    package: 'com.ehjouz.admin',
    // FCM config for Android push. On EAS, create a file env var GOOGLE_SERVICES_JSON from your google-services.json.
    ...(process.env.GOOGLE_SERVICES_JSON ? { googleServicesFile: process.env.GOOGLE_SERVICES_JSON } : {}),
    adaptiveIcon: {
      backgroundColor: '#3A4145',
      foregroundImage: './assets/android-icon-foreground.png',
      backgroundImage: './assets/android-icon-background.png',
      monochromeImage: './assets/android-icon-monochrome.png',
    },
    predictiveBackGestureEnabled: false,
    // Explicit alongside `scheme` below: belt-and-suspenders so the WordPress
    // approval redirect (ehjouz://auth) always has a registered intent filter,
    // even if a future prebuild step ever ignores the top-level `scheme`.
    intentFilters: [
      {
        action: 'VIEW',
        data: [{ scheme: 'ehjouz' }],
        category: ['BROWSABLE', 'DEFAULT'],
      },
    ],
  },
  plugins: [
    'expo-router',
    'expo-secure-store',
    'expo-font',
    [
      'expo-splash-screen',
      {
        image: './assets/splash-icon.png',
        imageWidth: 160,
        backgroundColor: '#F3F5F4',
        dark: { backgroundColor: '#2C3236' },
      },
    ],
    [
      'expo-notifications',
      {
        // No custom small-icon asset yet — Android falls back to the app icon. Add one under
        // assets/ (96x96, all-white with transparency) and reference it here when branding is ready.
        color: '#0B5C6B',
      },
    ],
  ],
  extra: {
    eas: {
      // Required for push notifications. `eas init` writes it here, or set EXPO_PUBLIC_EAS_PROJECT_ID for the build.
      projectId: process.env.EXPO_PUBLIC_EAS_PROJECT_ID || undefined,
    },
  },
};

export default config;

