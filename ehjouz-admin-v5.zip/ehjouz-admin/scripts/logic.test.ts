import assert from 'node:assert/strict';
import { toBase64, normalizeSiteUrl, buildQuery, restUrl } from '../src/lib/api';
import { partsAt, parseZone, keyOf, addDays, startOfWeek, weekdayOf, formatClock, untilLabel, formatDuration, formatDayLong } from '../src/lib/time';
import { decodeHtml } from '../src/lib/decode';

// base64 must match Node's for ASCII and non-Latin1 (Arabic username), incl. padding cases
for (const s of ['a', 'ab', 'abc', 'user:abcd efgh', 'مالك:pässword', 'x'.repeat(100)]) {
  assert.equal(toBase64(s), Buffer.from(s, 'utf8').toString('base64'), s);
}

// URL normalisation
assert.equal(normalizeSiteUrl('booking.example.com'), 'https://booking.example.com');
assert.equal(normalizeSiteUrl('  https://Example.com/wp-admin/  '), 'https://Example.com');
assert.equal(normalizeSiteUrl('http://localhost:8080/blog/wp-login.php?x=1'), 'http://localhost:8080/blog');
assert.equal(normalizeSiteUrl('https://a.com/wp-json/booknetic/v1'), 'https://a.com');
assert.equal(normalizeSiteUrl(''), null);

// Query building: arrays use PHP-style key[], empties are dropped, values encoded
assert.equal(buildQuery({ a: 1, b: '', c: undefined, d: [1, 2], e: 'x y' }), 'a=1&d[]=1&d[]=2&e=x%20y');
assert.equal(restUrl({ siteUrl: 'https://s.com', restStyle: 'pretty' }, 'booknetic/v1', '/appointments', { limit: 5 }), 'https://s.com/wp-json/booknetic/v1/appointments?limit=5');
assert.equal(restUrl({ siteUrl: 'https://s.com', restStyle: 'plain' }, 'booknetic/v1', '/appointments', { limit: 5 }), 'https://s.com/?rest_route=/booknetic/v1/appointments&limit=5');

// Timezones. 2026-09-21T12:00:00Z
const e = Date.UTC(2026, 8, 21, 12, 0, 0) / 1000;
assert.deepEqual(partsAt(e, parseZone('UTC+3')), { y: 2026, m: 9, d: 21, h: 15, mi: 0 });
assert.deepEqual(partsAt(e, parseZone('UTC-5.5')), { y: 2026, m: 9, d: 21, h: 6, mi: 30 });
assert.deepEqual(partsAt(e, parseZone('UTC')), { y: 2026, m: 9, d: 21, h: 12, mi: 0 });
assert.deepEqual(partsAt(e, parseZone('Asia/Beirut')), { y: 2026, m: 9, d: 21, h: 15, mi: 0 }); // DST in September
assert.deepEqual(partsAt(Date.UTC(2026, 0, 15, 12) / 1000, parseZone('Asia/Beirut')), { y: 2026, m: 1, d: 15, h: 14, mi: 0 }); // winter
assert.deepEqual(partsAt(Date.UTC(2026, 8, 21, 22, 30) / 1000, parseZone('Asia/Riyadh')), { y: 2026, m: 9, d: 22, h: 1, mi: 30 }); // crosses midnight
assert.deepEqual(partsAt(Date.UTC(2026, 8, 21, 21, 5) / 1000, parseZone('America/New_York')), { y: 2026, m: 9, d: 21, h: 17, mi: 5 });
// midnight must be hour 0, never 24
assert.equal(partsAt(Date.UTC(2026, 8, 21, 21, 0) / 1000, parseZone('Asia/Beirut')).h, 0);
assert.equal(parseZone('Not/AZone').tz, null); // invalid falls back to device

// Calendar keys
assert.equal(keyOf({ y: 2026, m: 9, d: 5, h: 0, mi: 0 }), '2026-09-05');
assert.equal(weekdayOf('2026-09-21'), 1); // Monday
assert.equal(startOfWeek('2026-09-21', 0), '2026-09-20');
assert.equal(startOfWeek('2026-09-21', 1), '2026-09-21');
assert.equal(startOfWeek('2026-09-20', 1), '2026-09-14');
assert.equal(startOfWeek('2026-09-21', 6), '2026-09-19');
assert.equal(addDays('2026-12-30', 3), '2027-01-02');
assert.equal(addDays('2026-03-01', -1), '2026-02-28');
assert.equal(formatDayLong('2026-09-21'), 'Monday, September 21');

// Clock
assert.equal(formatClock({ h: 0, mi: 5 }, true), '12:05 AM');
assert.equal(formatClock({ h: 12, mi: 0 }, true), '12:00 PM');
assert.equal(formatClock({ h: 15, mi: 7 }, true), '3:07 PM');
assert.equal(formatClock({ h: 9, mi: 3 }, false), '09:03');

// Countdown + duration
assert.equal(untilLabel(1000 + 23 * 60, 5000, 1000), 'In 23 min');
assert.equal(untilLabel(1000, 5000, 2000), 'In progress');
assert.equal(untilLabel(1000 + 125 * 60, 99999, 1000), 'In 2 h 5 min');
assert.equal(untilLabel(1000 + 20, 5000, 1000), 'Starting now');
assert.equal(formatDuration(45 * 60), '45 min');
assert.equal(formatDuration(90 * 60), '1 h 30 min');

// HTML decoding
assert.equal(decodeHtml('<span class="x">&#36;1,200.00</span>'), '$1,200.00');
assert.equal(decodeHtml('SAR&nbsp;90 &amp; up'), 'SAR\u00a090 & up');
console.log('all logic checks passed');


// --- Month grid ---
import { addMonths, daysInMonthCount, isInMonth, monthGridDays, startOfMonth } from '../src/lib/time';

assert.equal(startOfMonth('2026-09'), '2026-09-01');
assert.equal(daysInMonthCount('2026-09'), 30);
assert.equal(daysInMonthCount('2026-02'), 28); // 2026 not a leap year
assert.equal(daysInMonthCount('2024-02'), 29); // 2024 is a leap year
assert.equal(addMonths('2026-09', 1), '2026-10');
assert.equal(addMonths('2026-12', 1), '2027-01');
assert.equal(addMonths('2026-01', -1), '2025-12');

// September 2026: 1st is a Tuesday. Week starting Sunday(0):
const gridSun = monthGridDays('2026-09', 0);
assert.equal(gridSun.length % 7, 0);
assert.equal(gridSun[0], '2026-08-30'); // Sunday before the 1st
assert.ok(gridSun.includes('2026-09-01'));
assert.ok(gridSun.includes('2026-09-30'));
assert.equal(weekdayOf(gridSun[0]), 0);
assert.equal(weekdayOf(gridSun[gridSun.length - 1]), 6);

// Same month, week starting Monday(1):
const gridMon = monthGridDays('2026-09', 1);
assert.equal(gridMon.length % 7, 0);
assert.equal(gridMon[0], '2026-08-31'); // Monday before the 1st
assert.equal(weekdayOf(gridMon[0]), 1);

assert.equal(isInMonth('2026-09-15', '2026-09'), true);
assert.equal(isInMonth('2026-08-30', '2026-09'), false);

console.log('month grid checks passed');

// --- Week view ---
import { formatWeekRange, weekDays } from '../src/lib/time';

assert.deepEqual(weekDays('2026-09-23', 1), ['2026-09-21', '2026-09-22', '2026-09-23', '2026-09-24', '2026-09-25', '2026-09-26', '2026-09-27']); // Monday-first
assert.equal(weekDays('2026-09-23', 0)[0], '2026-09-20'); // Sunday-first
assert.equal(weekDays('2026-09-20', 1)[6], '2026-09-20'); // Sunday belongs to the week that started Monday 14th..20th
assert.equal(weekDays('2026-12-31', 1).length, 7);
assert.equal(formatWeekRange(weekDays('2026-09-23', 1)), '21 – 27 Sep 2026');
assert.equal(formatWeekRange(weekDays('2026-09-30', 1)), '28 Sep – 4 Oct 2026');
console.log('week checks passed');


// --- Business zone <-> phone zone slot conversion ---
import { offsetSecAt, parseZone as pz, partsAt as pa, wallToEpoch } from '../src/lib/time';
const beirut = pz('Asia/Beirut'); // UTC+3 in summer, +2 in winter
const utc3 = pz('UTC+3');
const ny = pz('America/New_York');
// 09:00 business time (UTC+3) is 06:00 UTC
assert.equal(wallToEpoch('2026-09-30', '09:00', utc3), Date.UTC(2026, 8, 30, 6, 0) / 1000);
// Beirut is on DST until late October, then UTC+2
assert.equal(offsetSecAt(Date.UTC(2026, 8, 30, 12) / 1000, beirut), 3 * 3600);
assert.equal(offsetSecAt(Date.UTC(2026, 11, 15, 12) / 1000, beirut), 2 * 3600);
// Same wall clock round-trips through the business zone
const rt = wallToEpoch('2026-12-15', '23:30', beirut);
assert.deepEqual(pa(rt, beirut), { y: 2026, m: 12, d: 15, h: 23, mi: 30 });
// A late business slot lands on the NEXT calendar day for a phone further east (UTC+3 -> UTC+5)
const utc5 = pz('UTC+5');
const late = pa(wallToEpoch('2026-09-30', '22:30', utc3), utc5);
assert.equal(`${late.y}-${late.m}-${late.d} ${late.h}:${late.mi}`, '2026-10-1 0:30');
// ...and an early slot lands on the PREVIOUS day for a phone further west
const early = pa(wallToEpoch('2026-10-01', '01:00', utc3), ny);
assert.equal(`${early.m}-${early.d}`, '9-30');
console.log('zone conversion checks passed');
