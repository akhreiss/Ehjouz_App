# Ehjouz Admin

Mobile app (Expo SDK 57, React Native 0.86, TypeScript) for **Booknetic SaaS tenant admins and staff**.
It talks to the REST API that already ships inside the Booknetic plugin (v1.3.5, namespace `booknetic/v1`),
so **no changes to Booknetic are needed** for v1.

## Run it

```bash
npm install
npm start            # then press a/i, or scan the QR code with Expo Go
npm run check        # typecheck + logic tests
```

Optional: lock the app to one server (hides the site field on the login screen):

```bash
EXPO_PUBLIC_LOCKED_SITE_URL=https://booking.example.com npm start
```

Before shipping: replace the placeholder icons/splash in `assets/`, and change the bundle id / package
(`com.ehjouz.admin`) and scheme (`ehjouz`) in `app.config.ts`.

## What's in v1

| Tab | Does |
|---|---|
| Today | Capacity ring (today's bookings as a share of business hours), revenue/bookings, a rail of new customers / pending / canceled, a pending-confirmations banner, a live timeline with customer avatars, and a Tomorrow section with a WhatsApp reminder button per customer |
| Calendar | A one-week strip (prev/next week, "Back to today") — tap any day to see its agenda below — or all bookings with search, Upcoming / Finished filter, and multi-select bulk actions |
| Customers | Search, detail (call / WhatsApp / email, booking history), add and edit |
| Alerts | Notification feed, unread badge, tap to open the booking — a pending booking's push also carries Approve/Reject buttons |
| Account | Who you're signed in as, sign out (revokes this device's app password and push token), link to the full web dashboard |

Booking screens: detail, change status, reschedule (real available times), create (existing or new customer), delete.
Settings-heavy areas (services, staff, hours, payments, workflows) intentionally stay on the web dashboard.

## How sign-in works

**v1 scope:** tenant-admin (business owner) login only. Staff sign-in is not built yet — a staff account's real
credentials will be rejected with a clear message, both by the companion plugin and by the app's own check after
sign-in, whichever path was used.

Primary flow (matches the official Booknetic app's UX — site, username, password, one tap):

1. The app reads `/wp-json/` to confirm Booknetic is installed, and to check whether the **Ehjouz Companion**
   plugin (`/wordpress-companion/ehjouz-companion.php`) is installed on the site.
2. If it is, the app calls `POST /wp-json/ehjouz/v1/login` with the real username and password. The plugin verifies
   them with `wp_authenticate()`, confirms the account is an owner role, and returns a scoped WordPress **application
   password** — the real password is never stored or sent again. The app stores that in the device keychain
   (`expo-secure-store`) and sends it as HTTP Basic auth on every request from then on.
3. Signing in again reuses the same device's application password rather than creating a new one each time.

**Why this needs a companion plugin:** Booknetic's REST API only accepts application passwords over Basic auth, never
the real account password (confirmed by reading `RestRoute::checkAuth()`), and WordPress core has no built-in "trade a
real password for an application password" endpoint. The plugin is the small piece that bridges that gap. Install it
under `wp-content/mu-plugins/` (auto-activates) or as a regular plugin.

**Without the companion plugin installed**, the primary form shows a clear message and points at the fallback below —
the app never silently degrades.

Fallbacks, both reachable from links under the Sign in button:
- **Sign in via browser** — the original flow: opens WordPress' own app-password approval page in-browser, the owner
  approves, WordPress redirects back to `ehjouz://auth?user_login=…&password=…`.
- **Paste an app password** — manual entry (WordPress → Users → Profile → Application Passwords).

Requirements and gotchas:
- **HTTPS is required** for application passwords (except on local dev sites). Some security plugins and hosts disable them.
  The companion plugin's `/login` route refuses to run without HTTPS for the same reason.
- **Authorization header stripped** (login says credentials were rejected, but they're right): common on Apache/FastCGI.
  Add to `.htaccess` above `# BEGIN WordPress`:
  ```
  RewriteEngine On
  RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]
  ```
  On nginx: `fastcgi_param HTTP_AUTHORIZATION $http_authorization;`
- In Expo Go the browser-fallback redirect uses an `exp://` URL instead of `ehjouz://`; WordPress accepts both.
- The browser-flow "page not found" flash some testers saw: Chrome briefly can't find a handler for `ehjouz://` the
  moment a fresh APK install hasn't finished registering the scheme with Android, then the same redirect is still
  picked up underneath and the app signs in anyway. It's cosmetic, and the primary flow above sidesteps it entirely
  by never leaving the app.

## API notes (from reading the Booknetic source)

- Successful responses are wrapped `{ success, message, data }`; lists are `data.data` + `data.meta`; void endpoints return 204;
  errors are WP_Error `{ code, message, data: { status, errors } }`. `src/lib/api.ts` unwraps all of this.
- Appointment times are epoch seconds and are shown in the **phone's** timezone.
- Verified against the Booknetic core: the server reads every booked/rescheduled `date` + `time` and every list
  `startsAt`/`endsAt` filter in the **business** timezone (`Date::epoch`), and `/appointments/available-times` returns
  plain business-zone `HH:MM` ids. `client_time_zone` does not move a booking, so the app does not send it. Instead it
  asks for the business-zone date(s) overlapping the chosen phone day, converts each slot to phone time, and books with the
  slot's original business date/time. The business zone comes from `/settings/general` (admin accounts); without it the
  app assumes the phone and business zones match. Day lists fetch one day either side and keep the phone's day.
- Date filters accept `YYYY-MM-DD` (interpreted in the tenant timezone).
- `isFinished=1` means already ended (matches the repository query). The backend's own `/appointments/filters` labels it the other way round.
- `/dashboard/graph` returns rendered HTML, so it isn't used.
- The stats endpoint needs the dashboard capability; when it's denied the ledger is simply hidden.

## Appearance

Follows the system light/dark setting by default; Account → Appearance lets the person pin it to Light or Dark
instead, stored on-device. Dark mode uses a charcoal background (`#1C2224`), not near-black, to avoid OLED-crush.

## Push notifications

The companion plugin now does the full job: `POST /ehjouz/v1/devices` registers an Expo push token for the
signed-in user, and hooking `bkntc_appointment_before_mutation` / `bkntc_appointment_after_mutation` (the exact
before/after snapshot pattern Booknetic's own `Config.php` uses internally to detect status changes) lets it tell
apart a new booking, a cancellation, any other status change, and a reschedule. On each of those it writes a row to
Booknetic's own mobile-notification feed — same table, same `type = 'mobile_app_notification'` the app's Alerts tab
and unread badge already read, so nothing changed on that side — and sends a push via Expo's push service
(`https://exp.host`), which needs no FCM/APNs credentials of your own. A note-only edit, or anything that isn't one
of those four changes, is intentionally silent.

On a SaaS install the alert goes to the tenant's owner (via `BookneticSaaS\Models\Tenant`, resolved off the
appointment's `tenant_id`, the same trait Booknetic's own models use). On a non-SaaS install it goes to whichever
site administrator has a device registered. Every DB write and push send is best-effort and wrapped so it can never
break the booking request that triggered it.

**To actually receive a push, two things need to happen once, outside this repo:**

1. **Link the app to an EAS project** — `npx eas init` (needs a free Expo account), which fills in
   `extra.eas.projectId` in `app.config.ts`. Without it the app silently skips push registration; everything else
   keeps working.
2. **Build a dev client or a standalone build** — `eas build --profile development` (or `npx expo run:android` /
   `run:ios` locally). **Expo Go cannot receive remote push** (Android since SDK 53, iOS since SDK 51), so this
   was never a physical-device-vs-simulator question — it's Expo Go vs a real build, on any device.

Once both are done: sign in, accept the permission prompt, and the token registers automatically. Tapping a push
opens the booking it's about; the Alerts tab and unread badge update the same way they already did.

## Bulk actions, actionable push, WhatsApp reminders

Three more things, on top of what's above.

**Bulk actions** — Calendar → All bookings → the checkmark icon next to search enters select mode. Confirm and
Cancel bulk-update status via Booknetic's `POST /appointments/bulk-update`; Delete uses `DELETE /appointments/bulk`.
Both accept up to 500 ids per request and report partial success (`{succeeded, failed, errors}`), which the app
surfaces as e.g. "4 of 5 confirmed — 1 couldn't be changed" rather than pretending it was all-or-nothing.

**Actionable push** — a booking that lands in (or is set to) `pending` status now gets a push with Approve/Reject
buttons right on the notification, via the companion plugin's `booking_pending` category. One honest caveat:
both buttons are set to foreground the app (`opensAppToForeground: true`). That's deliberate, not laziness — the
alternative, fulfilling the action silently in the background, simply doesn't fire at all once the app has been
fully killed rather than just backgrounded, which is a common real-world state. So tapping Approve or Reject briefly
opens the app, applies the status change, and lands on that booking already updated — faster than the manual path,
but not a fully silent background action.

**WhatsApp reminders (manual assist)** — Today now has a Tomorrow section below the schedule, and each row with a
phone number gets a WhatsApp button that opens a pre-filled reminder message via `wa.me`. One real API constraint
worth knowing: the appointments list endpoint doesn't return phone numbers or a customer id, only the single-booking
detail endpoint does. So each Tomorrow row lazily fetches its own detail (`GET /appointments/{id}`) just to get the
phone — cached per id, and fine for the handful of bookings a day typically has, but worth knowing if that section
ever needs to scale to a lot of rows at once. This is the "manual" version discussed earlier: one tap per customer,
no Meta/WhatsApp Business API integration, no per-message cost. The fully automated version (sent without the owner
tapping anything) is still a separate, larger decision — see the "Later" list.

## The Today/Calendar redesign

What was previewed in chat is now real code, built against actual API data rather than the mockup's placeholder
numbers — with a couple of deliberate simplifications and one real trade-off worth knowing about.

**The capacity ring** (Today) is a genuine calculation, not a guess: `GET /settings/business-hours` gives today's
working hours and break windows, `lib/time.ts`'s `computeCapacity()` turns that into available minutes, and today's
active (non-canceled) booking durations are summed and divided against it. It's owner-only data — if that route 403s
(shouldn't happen for a tenant admin, but defensively handled), the ring just doesn't render; Today falls back to
showing revenue and a plain booking count instead of showing a made-up percentage. A day marked off in Business Hours
shows "Closed" in the ring's place rather than a 0%, which would read as "nothing booked" instead of "not open."

**The rail** (new customers / pending / canceled) only shows numbers I could confirm are real: "new customers" is
genuinely `Customer.created_at` within the period, not "customers active this period" — I'd flagged that as unverified
earlier and checked it against `DashboardRepository::getCustomerCountByDateRange()` this round; it's accurate. I did
**not** build the mockup's "average ticket" or "no-shows" chips — neither is backed by anything Booknetic's API
actually returns, and I'd rather ship fewer numbers than a fabricated one.

**Removed, on purpose:** the This week / This month stats toggle that used to be on Today. The ring and rail are
today-only by design (a "% of this week's hours booked" reads oddly), and the redesign as previewed didn't have a
period switcher. If you want week/month totals reachable from somewhere, they're not currently anywhere in the app —
worth deciding where that should live, if anywhere.

**Calendar's week strip** shows up to 3 dots per day for booking count, a ring around today, and a filled cell for
the selected day; tapping a day loads its agenda underneath, same pattern as Google/Apple Calendar. One thing from
the mockup I deliberately left out: the dashed amber "nearly full day" ring on grid cells. Doing that honestly means
running the same capacity calculation per visible day (up to ~42 of them) instead of once, which is real added
complexity for a secondary affordance — happy to add it if it's worth that cost to you. The week-strip view is gone,
per the plan from last time; Week and All bookings are the two ways to browse now.

**Agenda rows** (Today's timeline, and the schedule under each Calendar day) now show a customer avatar with the
status color as a ring around it, replacing the separate colored dot. The "now" marker on Today is the one dot left
on the timeline, which was the point — it stands out again instead of competing with four others.

**Tab bar:** Today moved from the "today" calendar-with-a-dot icon to a sun icon, so it no longer looks like a
smaller version of the Calendar tab's icon.

None of this has run against staging yet — see "Verified" below.

## Fixed since the first build

- **"Please fill in all required fields correctly" on every new booking**, even with everything filled in. Root
  cause, confirmed by reading `AppointmentRequestData::validateCustomerData()`: Booknetic's REST API always creates
  appointments in "backend" mode, which requires an **existing** `customerId` and has no way to create a customer
  inline — the `customer_data` field only works on the public booking widget's own flow, not this one. The New
  booking screen's "New customer" option now creates the customer first (`POST /customers`) and books with the id
  it gets back, instead of sending customer details alongside the booking.
- Dropped a related bug: when a business has zero active locations, the app was sending `location: 0` to make the
  request "complete" — but PHP's `empty(0)` is `true`, so that always failed the same validation. It now shows a
  plain message instead of a silent failure.
- Dark mode was too close to black; it's a proper mid gray now (`#2C3236`).

## Verified

Login, Customers, and booking creation/reschedule/status/delete have been run against staging on a physical Android
device and confirmed working. **Today and Calendar have since been substantially rewritten** for the redesign above,
so that earlier on-device confirmation no longer covers what's actually in those two screens now — they've only
been checked with `tsc`, the logic tests (including the capacity-math and month-grid unit tests), and a full Android
bundle export. Also not yet exercised on staging: bulk actions, actionable push, WhatsApp reminders, plain push
notifications (needs the two one-time setup steps above), and money formatting on booking detail (needs the
owner-only `/settings/payments` route).

## Later

Arabic + RTL (layout already uses start/end spacing; add an i18n layer), multi-staff calendar columns, offline cache,
staff sign-in, a fully automated WhatsApp reminder path (needs Meta's WhatsApp Business Cloud API — a registered
business number, app review, and pre-approved message templates, quite a bit more than the manual-assist version
built here), the "nearly full day" indicator on Calendar's month cells, and somewhere for week/month stats to live
now that Today only shows today's numbers.

## v3/v4 notes

- **Push checklist:** set `EXPO_PUBLIC_EAS_PROJECT_ID` (or run `eas init`), use a dev-client/standalone build (not Expo Go),
  upload FCM (Android) / APNs (iOS) credentials to EAS, and keep the Ehjouz Companion plugin current. Account → **Push**
  shows exactly which step is missing.
- **Capacity ring:** booked time ÷ (business hours × number of staff). Individual staff schedules/days off are not read.
- **Approve:** pending bookings show an Approve button on rows and Approve/Reject on the booking screen.

## v5 notes

- **Home header:** hours booked today (pending included, canceled/rejected excluded), revenue (dashboard stats; falls back
  to the value of today's bookings, labelled "Booked value"), and booking count. The capacity gauge was removed.
- **Confirm pending bookings** opens All bookings on a new **Pending** filter (every pending booking, oldest first).
- **Build the APK:** `eas build --platform android --profile preview` (needs `eas init` once, and the push steps above).
  Android push also needs a Firebase project: add the Android app `com.ehjouz.admin`, download `google-services.json`,
  set it as the EAS file env var `GOOGLE_SERVICES_JSON`, and upload an FCM v1 service-account key under
  `eas credentials` → Android → Push notifications.
- **Companion plugin 0.3.0:** fixes literal `\u2019` showing in alert text, sends `channelId`/high priority, and
  removes device tokens Expo reports as dead. Bookings made through the app's own REST calls do not fire Booknetic's
  mutation hooks, so only customer bookings and web-admin edits raise alerts.
