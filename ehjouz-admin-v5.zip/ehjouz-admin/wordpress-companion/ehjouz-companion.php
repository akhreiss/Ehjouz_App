<?php
/**
 * Plugin Name: Ehjouz Companion
 * Description: Lets the Ehjouz mobile app sign tenant admins in with just a username and
 *              password, by exchanging that one real login for a scoped WordPress application
 *              password on the app's behalf. Also registers push-notification device tokens and
 *              writes/sends an alert on new bookings, cancellations, status changes and
 *              reschedules. Requires the Booknetic plugin.
 * Version:     0.3.0
 *
 * Install: upload this single file to wp-content/mu-plugins/ (or activate it as a regular
 * plugin under wp-content/plugins/ehjouz-companion/ehjouz-companion.php).
 */

if (!defined('ABSPATH')) {
    exit;
}

define('EHJOUZ_NAMESPACE', 'ehjouz/v1');
define('EHJOUZ_APP_NAME', 'Ehjouz');
define('EHJOUZ_TOKENS_META_KEY', 'ehjouz_push_tokens');
define('EHJOUZ_MAX_TOKENS_PER_USER', 10);

add_action('rest_api_init', function () {
    register_rest_route(EHJOUZ_NAMESPACE, '/login', [
        'methods'             => 'POST',
        'callback'            => 'ehjouz_handle_login',
        'permission_callback' => '__return_true', // Auth happens inside the callback, same as wp-login.php.
        'args'                => [
            'username' => ['required' => true, 'type' => 'string'],
            'password' => ['required' => true, 'type' => 'string'],
        ],
    ]);

    register_rest_route(EHJOUZ_NAMESPACE, '/devices', [
        'methods'             => 'POST',
        'callback'            => 'ehjouz_register_device',
        'permission_callback' => static fn () => is_user_logged_in(),
        'args'                => [
            'token'    => ['required' => true, 'type' => 'string'],
            'platform' => ['type' => 'string'],
        ],
    ]);

    register_rest_route(EHJOUZ_NAMESPACE, '/devices', [
        'methods'             => 'DELETE',
        'callback'            => 'ehjouz_unregister_device',
        'permission_callback' => static fn () => is_user_logged_in(),
        'args'                => ['token' => ['required' => true, 'type' => 'string']],
    ]);
});

/**
 * Trades a real username/password for an application password, scoped to this app, without
 * ever storing the real password. This is the same trust boundary as wp-login.php — it must
 * only ever be served over HTTPS.
 */
function ehjouz_handle_login(WP_REST_Request $request)
{
    if (!is_ssl() && 'local' !== wp_get_environment_type()) {
        return new WP_Error('ehjouz_https_required', 'This site must use HTTPS to sign in from the app.', ['status' => 400]);
    }

    $username = (string) $request->get_param('username');
    $password = (string) $request->get_param('password');

    $user = wp_authenticate($username, $password);
    if (is_wp_error($user)) {
        return new WP_Error('ehjouz_invalid_credentials', 'The username or password is incorrect.', ['status' => 401]);
    }

    // v1 scope: tenant admins only (or site administrators). Staff sign-in is a later phase.
    if (!array_intersect(['administrator', 'booknetic_saas_tenant'], (array) $user->roles)) {
        return new WP_Error(
            'ehjouz_not_supported',
            'The Ehjouz app currently supports business-owner accounts only. Staff sign-in is coming soon.',
            ['status' => 403]
        );
    }

    if (!class_exists('WP_Application_Passwords')) {
        return new WP_Error('ehjouz_app_passwords_unavailable', 'Application passwords are turned off on this site.', ['status' => 500]);
    }

    // Reuse this device's app password if it already made one, instead of piling up new ones
    // every time the app opens. The app sends the same device_name every time it calls this.
    $deviceName = sanitize_text_field((string) $request->get_param('device_name')) ?: 'Ehjouz app';
    $appName    = EHJOUZ_APP_NAME . ' — ' . $deviceName;

    foreach (WP_Application_Passwords::get_user_application_passwords($user->ID) as $existing) {
        if (($existing['name'] ?? '') === $appName) {
            WP_Application_Passwords::delete_application_password($user->ID, $existing['uuid']);
            break;
        }
    }

    $created = WP_Application_Passwords::create_new_application_password($user->ID, ['name' => $appName]);
    if (is_wp_error($created)) {
        return new WP_Error('ehjouz_could_not_create', 'Could not finish signing in. Please try again.', ['status' => 500]);
    }

    [$rawPassword] = $created;

    return new WP_REST_Response([
        'username' => $user->user_login,
        'password' => $rawPassword,
        'name'     => $user->display_name,
    ], 200);
}

/* -------------------------------------------------------------------------------------------- *
 * Device tokens
 *
 * One WP user (the tenant admin) can have a few devices. Kept as user meta — simple, and there's
 * no meaningful case for querying across users by token, which is the usual reason to reach for a
 * dedicated table instead.
 * -------------------------------------------------------------------------------------------- */

function ehjouz_register_device(WP_REST_Request $request)
{
    $userId = get_current_user_id();
    $token  = trim((string) $request->get_param('token'));
    if ($token === '') {
        return new WP_Error('ehjouz_invalid_token', 'A device token is required.', ['status' => 400]);
    }
    $platform = sanitize_text_field((string) $request->get_param('platform'));

    $tokens = ehjouz_get_tokens($userId);
    $tokens = array_values(array_filter($tokens, static fn ($t) => ($t['token'] ?? '') !== $token));
    $tokens[] = ['token' => $token, 'platform' => $platform, 'updated_at' => time()];
    if (count($tokens) > EHJOUZ_MAX_TOKENS_PER_USER) {
        $tokens = array_slice($tokens, -EHJOUZ_MAX_TOKENS_PER_USER);
    }

    update_user_meta($userId, EHJOUZ_TOKENS_META_KEY, $tokens);

    return new WP_REST_Response(['success' => true], 200);
}

function ehjouz_unregister_device(WP_REST_Request $request)
{
    $userId = get_current_user_id();
    $token  = trim((string) $request->get_param('token'));

    $tokens = ehjouz_get_tokens($userId);
    $tokens = array_values(array_filter($tokens, static fn ($t) => ($t['token'] ?? '') !== $token));
    update_user_meta($userId, EHJOUZ_TOKENS_META_KEY, $tokens);

    return new WP_REST_Response(['success' => true], 200);
}

function ehjouz_get_tokens(int $userId): array
{
    $tokens = get_user_meta($userId, EHJOUZ_TOKENS_META_KEY, true);
    return is_array($tokens) ? $tokens : [];
}

/* -------------------------------------------------------------------------------------------- *
 * Booking alerts
 *
 * Booknetic fires `bkntc_appointment_before_mutation( $id|null )` then, after the write,
 * `bkntc_appointment_after_mutation( $id )` — on create, $id is null on the "before" call and the
 * new id on "after"; on update, both calls carry the same id. This is the same pattern Booknetic's
 * own Config.php uses internally to detect what changed. We snapshot on "before" and diff on
 * "after" the same way, then write a row to Booknetic's own mobile-notification feed (so the
 * Alerts tab needs no server-shape changes) and send an Expo push alongside it.
 * -------------------------------------------------------------------------------------------- */

$ehjouz_snapshot = new stdClass();
$ehjouz_snapshot->before = null;

add_action('bkntc_appointment_before_mutation', static function ($id) use ($ehjouz_snapshot) {
    $ehjouz_snapshot->before = ($id && class_exists('\BookneticApp\Models\Appointment'))
        ? \BookneticApp\Models\Appointment::query()->get($id)
        : null;
});

add_action('bkntc_appointment_after_mutation', static function ($id) use ($ehjouz_snapshot) {
    $before = $ehjouz_snapshot->before;
    $ehjouz_snapshot->before = null;
    ehjouz_notify_appointment_mutation($id, $before);
});

function ehjouz_notify_appointment_mutation($id, $before): void
{
    if (empty($id) || !class_exists('\BookneticApp\Models\Appointment')) {
        return;
    }

    $after = \BookneticApp\Models\Appointment::query()->get($id);
    if (!$after) {
        return; // Hard-deleted — not alerted on in v1; cancellation (a status change) is.
    }

    $isNew         = $before === null;
    $statusChanged = !$isNew && $before->status !== $after->status;
    $rescheduled   = !$isNew && !$statusChanged
        && ((int) $before->starts_at !== (int) $after->starts_at || (int) $before->staff_id !== (int) $after->staff_id);

    if (!$isNew && !$statusChanged && !$rescheduled) {
        return; // e.g. a note-only edit — nothing a tenant needs an alert for.
    }

    $customerName = __('A customer', 'booknetic');
    if (class_exists('\BookneticApp\Models\Customer')) {
        $customer = \BookneticApp\Models\Customer::query()->get($after->customer_id);
        $name     = trim(($customer->first_name ?? '') . ' ' . ($customer->last_name ?? ''));
        if ($name !== '') {
            $customerName = $name;
        }
    }

    $canceled = $statusChanged && in_array($after->status, ['canceled', 'cancelled', 'rejected'], true);

    if ($isNew) {
        $title   = __('New booking', 'booknetic');
        $message = sprintf(__('%s just booked an appointment.', 'booknetic'), $customerName);
    } elseif ($canceled) {
        $title   = __('Booking canceled', 'booknetic');
        $message = sprintf(__("%s\u{2019}s appointment was canceled.", 'booknetic'), $customerName);
    } elseif ($statusChanged) {
        $title   = __('Booking status changed', 'booknetic');
        $message = sprintf(__("%1\$s\u{2019}s appointment is now %2\$s.", 'booknetic'), $customerName, $after->status);
    } else {
        $title   = __('Booking rescheduled', 'booknetic');
        $message = sprintf(__("%s\u{2019}s appointment time changed.", 'booknetic'), $customerName);
    }

    $ownerUserId = ehjouz_resolve_owner_user_id();
    if (!$ownerUserId) {
        return;
    }

    if (class_exists('\BookneticApp\Models\Notification')) {
        // Same table and 'type' the app's existing Alerts tab already reads — no app change needed.
        \BookneticApp\Models\Notification::query()->withoutGlobalScope('user_id')->insert([
            'user_id'     => $ownerUserId,
            'type'        => 'mobile_app_notification',
            'title'       => $title,
            'message'     => $message,
            'action_type' => 'appointment',
            'action_data' => wp_json_encode(['appointment_id' => (int) $id]),
        ]);
    }

    // Actionable push: a booking sitting in "pending" is the one state that genuinely needs a
    // yes/no from the owner, so only that state gets Approve/Reject buttons on the notification
    // itself. The app registers a matching category ('booking_pending') at startup.
    $category = ($after->status === 'pending') ? 'booking_pending' : null;
    ehjouz_send_push($ownerUserId, $title, $message, ['appointmentId' => (int) $id], $category);
}

/** Resolves the WP user id who should be alerted: the tenant's owner on SaaS installs, or the site administrator(s) on a single-tenant install. */
function ehjouz_resolve_owner_user_id(): int
{
    if (class_exists('\BookneticApp\Providers\Core\Permission') && class_exists('\BookneticSaaS\Models\Tenant')) {
        $tenantId = \BookneticApp\Providers\Core\Permission::tenantId();
        if (!empty($tenantId)) {
            $tenant = \BookneticSaaS\Models\Tenant::where('id', $tenantId)->fetch();
            if ($tenant && !empty($tenant->user_id)) {
                return (int) $tenant->user_id;
            }
        }
    }

    $admins = get_users(['role' => 'administrator', 'fields' => 'ID']);
    foreach ($admins as $adminId) {
        if (!empty(ehjouz_get_tokens((int) $adminId))) {
            return (int) $adminId;
        }
    }

    return (int) ($admins[0] ?? 0);
}

/**
 * Sends via Expo's push service (https://exp.host). The phone app must be a build whose Android project has FCM
 * credentials uploaded to EAS (iOS: APNs) — Expo relays to Google/Apple, it does not replace them.
 * Best effort: a failed push must never break the booking request that triggered it. Tokens Expo reports as
 * dead (DeviceNotRegistered) are dropped so they stop being retried.
 */
function ehjouz_send_push(int $userId, string $title, string $body, array $data = [], ?string $categoryId = null): void
{
    $tokens = ehjouz_get_tokens($userId);
    if (empty($tokens)) {
        return;
    }

    $messages = [];
    $sentTo   = [];
    foreach ($tokens as $entry) {
        if (empty($entry['token'])) {
            continue;
        }
        // channelId must match the channel the app creates on Android ('default'), or Android 8+ may silence it.
        $message = ['to' => $entry['token'], 'title' => $title, 'body' => $body, 'data' => $data, 'sound' => 'default', 'priority' => 'high', 'channelId' => 'default'];
        if ($categoryId !== null) {
            $message['categoryId'] = $categoryId;
        }
        $messages[] = $message;
        $sentTo[]   = $entry['token'];
    }
    if (empty($messages)) {
        return;
    }

    $response = wp_remote_post('https://exp.host/--/api/v2/push/send', [
        'headers' => ['Content-Type' => 'application/json', 'Accept' => 'application/json'],
        'body'    => wp_json_encode($messages),
        'timeout' => 8,
    ]);

    if (is_wp_error($response)) {
        return;
    }

    $tickets = json_decode((string) wp_remote_retrieve_body($response), true)['data'] ?? [];
    $dead    = [];
    foreach ($tickets as $i => $ticket) {
        if (($ticket['status'] ?? '') === 'error' && ($ticket['details']['error'] ?? '') === 'DeviceNotRegistered' && isset($sentTo[$i])) {
            $dead[] = $sentTo[$i];
        }
    }
    if ($dead) {
        $keep = array_values(array_filter($tokens, static fn ($t) => !in_array($t['token'] ?? '', $dead, true)));
        update_user_meta($userId, EHJOUZ_TOKENS_META_KEY, $keep);
    }
}
